var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var require_app_css = __commonJS({
  "app.css.js"(exports) {
    const _style_0 = {};
    exports.styles = [_style_0];
  }
});
export default require_app_css();
