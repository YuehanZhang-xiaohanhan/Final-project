if (typeof Promise !== "undefined" && !Promise.prototype.finally) {
  Promise.prototype.finally = function(callback) {
    const promise = this.constructor;
    return this.then(
      (value) => promise.resolve(callback()).then(() => value),
      (reason) => promise.resolve(callback()).then(() => {
        throw reason;
      })
    );
  };
}
;
if (typeof uni !== "undefined" && uni && uni.requireGlobal) {
  const global = uni.requireGlobal();
  ArrayBuffer = global.ArrayBuffer;
  Int8Array = global.Int8Array;
  Uint8Array = global.Uint8Array;
  Uint8ClampedArray = global.Uint8ClampedArray;
  Int16Array = global.Int16Array;
  Uint16Array = global.Uint16Array;
  Int32Array = global.Int32Array;
  Uint32Array = global.Uint32Array;
  Float32Array = global.Float32Array;
  Float64Array = global.Float64Array;
  BigInt64Array = global.BigInt64Array;
  BigUint64Array = global.BigUint64Array;
}
;
if (uni.restoreGlobal) {
  uni.restoreGlobal(Vue, weex, plus, setTimeout, clearTimeout, setInterval, clearInterval);
}
(function(vue) {
  "use strict";
  function formatAppLog(type, filename, ...args) {
    if (uni.__log__) {
      uni.__log__(type, filename, ...args);
    } else {
      console[type].apply(console, [...args, filename]);
    }
  }
  const _export_sfc = (sfc, props) => {
    const target = sfc.__vccOpts || sfc;
    for (const [key, val] of props) {
      target[key] = val;
    }
    return target;
  };
  const _sfc_main$m = {
    globalData: {
      text: "http://192.168.31.171:8088",
      user: null
    },
    onLaunch: function() {
      formatAppLog("log", "at App.vue:9", "App Launch");
    },
    onShow: function() {
      formatAppLog("log", "at App.vue:12", "App Show");
    },
    onHide: function() {
      formatAppLog("log", "at App.vue:15", "App Hide");
    }
  };
  const App = /* @__PURE__ */ _export_sfc(_sfc_main$m, [["__file", "D:/Work/HBuilderProjects/hospital/hospital/App.vue"]]);
  const _imports_0$5 = "/static/cwd.png";
  const _sfc_main$l = {
    data() {
      return {
        login: {
          username: "",
          pass: "",
          role: "用户"
        },
        baseurl: ""
      };
    },
    onLoad() {
      this.baseurl = getApp().globalData.text;
    },
    methods: {
      changerole(e) {
        let that = this;
        formatAppLog("log", "at pages/login/login.vue:56", e.detail.value);
        that.login.role = e.detail.value;
      },
      dl() {
        let that = this;
        let role = that.login.role;
        let username = that.login.username;
        let pass = that.login.pass;
        if (username === "" || pass === "") {
          formatAppLog("log", "at pages/login/login.vue:66", "请填写完整信息");
          uni.showToast({
            title: "请填写完整信息",
            icon: "none",
            duration: 2e3
          });
        } else {
          if (role === "用户") {
            uni.request({
              url: that.baseurl + "/user/login",
              data: {
                username: that.login.username,
                pass: that.login.pass
              },
              success: (res) => {
                if (res.data.code === "200") {
                  getApp().globalData.user = res.data.data;
                  uni.switchTab({
                    url: "/pages/main/main"
                  });
                } else {
                  uni.showToast({
                    title: res.data.msg,
                    duration: 2e3,
                    icon: "none"
                  });
                }
                formatAppLog("log", "at pages/login/login.vue:95", res.data);
              }
            });
          } else {
            uni.request({
              url: that.baseurl + "/doctor/login",
              data: {
                username: that.login.username,
                pass: that.login.pass
              },
              success: (res) => {
                if (res.data.code === "200") {
                  getApp().globalData.user = res.data.data;
                  uni.reLaunch({
                    url: "/pages/Doctormain/Doctormain"
                  });
                } else {
                  uni.showToast({
                    title: res.data.msg,
                    duration: 2e3,
                    icon: "none"
                  });
                }
                formatAppLog("log", "at pages/login/login.vue:121", res.data);
              }
            });
          }
        }
      },
      regist() {
        uni.navigateTo({
          url: "/pages/regist/regist"
        });
      }
    }
  };
  function _sfc_render$l(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main-mian" }, [
      vue.createElementVNode("view", {
        class: "main",
        style: { "display": "flex", "flex-direction": "column", "align-items": "center", "justify-content": "center" }
      }, [
        vue.createElementVNode("image", {
          src: _imports_0$5,
          mode: "widthFix"
        }),
        vue.createElementVNode("text", { class: "title" }, "Hospital")
      ]),
      vue.createElementVNode("view", { class: "mian-login" }, [
        vue.createElementVNode("view", { class: "login" }, [
          vue.createElementVNode("view", { class: "login-title" }, [
            vue.createElementVNode("text", null, "Login")
          ]),
          vue.createElementVNode("view", { class: "login-username" }, [
            vue.createElementVNode("text", null, "UserName"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $data.login.username = $event),
                placeholder: "Please enter your account number",
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.login.username]
            ])
          ]),
          vue.createElementVNode("view", { class: "login-pass" }, [
            vue.createElementVNode("text", null, "Pass"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "password",
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $data.login.pass = $event),
                placeholder: " Please enter your password",
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.login.pass]
            ])
          ]),
          vue.createElementVNode("view", { class: "login-pass" }, [
            vue.createElementVNode("text", null, "Role"),
            vue.createElementVNode(
              "radio-group",
              {
                style: { "margin-top": "10px" },
                onChange: _cache[2] || (_cache[2] = (...args) => $options.changerole && $options.changerole(...args))
              },
              [
                vue.createElementVNode("radio", {
                  value: "用户",
                  checked: ""
                }, "User"),
                vue.createElementVNode("radio", {
                  value: "医生",
                  style: { "margin-left": "10px" }
                }, "Doctor")
              ],
              32
              /* NEED_HYDRATION */
            )
          ])
        ]),
        vue.createElementVNode("button", {
          class: "btn",
          onClick: _cache[3] || (_cache[3] = (...args) => $options.dl && $options.dl(...args))
        }, "Login"),
        vue.createElementVNode("view", {
          class: "regist",
          onClick: _cache[4] || (_cache[4] = (...args) => $options.regist && $options.regist(...args))
        }, " Register an account ")
      ])
    ]);
  }
  const PagesLoginLogin = /* @__PURE__ */ _export_sfc(_sfc_main$l, [["render", _sfc_render$l], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/login/login.vue"]]);
  const _imports_0$4 = "/static/head.png";
  const _sfc_main$k = {
    data() {
      return {
        login: {
          username: "",
          pass: "",
          nickname: "",
          tel: "",
          age: "",
          sex: "男"
        },
        head: "",
        baseurl: ""
      };
    },
    onLoad() {
      this.baseurl = getApp().globalData.text;
    },
    methods: {
      changesex(e) {
        formatAppLog("log", "at pages/regist/regist.vue:65", "e", e);
        let that = this;
        that.sex = e.detail.value;
      },
      regist() {
        let that = this;
        formatAppLog("log", "at pages/regist/regist.vue:71", that.login.username == "");
        if (that.login.username == "" || that.login.pass == "" || that.login.nickname == "" || that.login.tel == "" || that.head == "") {
          uni.showToast({
            title: "内容不能为空",
            duration: 2e3,
            icon: "none"
          });
        } else {
          uni.request({
            url: that.baseurl + "/user/add",
            data: {
              username: that.login.username,
              nickname: that.login.nickname,
              sex: that.login.sex,
              age: that.login.age,
              tel: that.login.tel,
              pass: that.login.pass,
              head: that.head
            },
            success(res) {
              formatAppLog("log", "at pages/regist/regist.vue:92", res);
              if (res.data.code == "500") {
                uni.showToast({
                  title: "账号已存在",
                  duration: 2e3,
                  icon: "none"
                });
              } else {
                uni.showToast({
                  title: "注册成功",
                  duration: 2e3,
                  icon: "success",
                  success() {
                    uni.navigateBack({ changed: true });
                  }
                });
              }
            }
          });
        }
      },
      choosepic() {
        let that = this;
        formatAppLog("log", "at pages/regist/regist.vue:118", "选择照片");
        uni.chooseImage({
          count: 1,
          sizeType: ["original"],
          sourceType: ["album"],
          success(res) {
            formatAppLog("log", "at pages/regist/regist.vue:124", res);
            res.tempFilePaths;
            var tempFilePathss = res.tempFilePaths;
            formatAppLog("log", "at pages/regist/regist.vue:127", "图片" + tempFilePathss);
            that.head = tempFilePathss;
            uni.uploadFile({
              url: that.baseurl + "/upload/imagewx",
              // 后端api接口
              filePath: tempFilePathss[0],
              // uni.chooseImage函数调用后获取的本地文件路劲
              name: "file",
              //后端通过'file'获取上传的文件对象
              formData: {
                "user": "test"
              },
              success: (res2) => {
                formatAppLog("log", "at pages/regist/regist.vue:137", res2);
                that.head = res2.data;
              }
            });
          }
        });
      }
    }
  };
  function _sfc_render$k(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        vue.createElementVNode("view", { class: "head" }, [
          $data.head === "" ? (vue.openBlock(), vue.createElementBlock("image", {
            key: 0,
            src: _imports_0$4,
            mode: "widthFix",
            onClick: _cache[0] || (_cache[0] = (...args) => $options.choosepic && $options.choosepic(...args))
          })) : vue.createCommentVNode("v-if", true),
          $data.head != "" ? (vue.openBlock(), vue.createElementBlock("image", {
            key: 1,
            src: `${$data.baseurl}/public/${$data.head}`,
            mode: "widthFix",
            onClick: _cache[1] || (_cache[1] = (...args) => $options.choosepic && $options.choosepic(...args))
          }, null, 8, ["src"])) : vue.createCommentVNode("v-if", true)
        ]),
        vue.createElementVNode("view", { class: "main-mian" }, [
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "UserName"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                placeholder: "Please enter your account number",
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $data.login.username = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.login.username]
            ])
          ]),
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "NickName"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                placeholder: "Please enter name",
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $data.login.nickname = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.login.nickname]
            ])
          ]),
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "Tel"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                placeholder: "Please enter phone number",
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => $data.login.tel = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.login.tel]
            ])
          ]),
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "Pass"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                placeholder: "Please enter your password",
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => $data.login.pass = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.login.pass]
            ])
          ]),
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "Age"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "number",
                placeholder: "Please enter your age",
                "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => $data.login.age = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.login.age]
            ])
          ]),
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "Sex"),
            vue.createElementVNode(
              "radio-group",
              {
                style: { "margin-top": "10px" },
                onChange: _cache[7] || (_cache[7] = (...args) => $options.changesex && $options.changesex(...args))
              },
              [
                vue.createElementVNode("radio", {
                  value: "男",
                  checked: ""
                }, "man"),
                vue.createElementVNode("radio", {
                  value: "女",
                  style: { "margin-left": "10px" }
                }, "woman")
              ],
              32
              /* NEED_HYDRATION */
            )
          ])
        ]),
        vue.createElementVNode("button", {
          class: "btn",
          onClick: _cache[8] || (_cache[8] = (...args) => $options.regist && $options.regist(...args))
        }, "注册"),
        vue.createElementVNode("view", { style: { "height": "100px" } })
      ])
    ]);
  }
  const PagesRegistRegist = /* @__PURE__ */ _export_sfc(_sfc_main$k, [["render", _sfc_render$k], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/regist/regist.vue"]]);
  const _imports_0$3 = "/static/ysj.png";
  const _sfc_main$j = {
    data() {
      return {
        baseurl: "",
        user: {},
        show: false
      };
    },
    onShow() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
    },
    methods: {
      exituser() {
        uni.showModal({
          title: "提示",
          content: "确认退出嘛 ？",
          success: function(res) {
            if (res.confirm) {
              uni.reLaunch({
                url: "/pages/login/login"
              });
            } else if (res.cancel) {
              formatAppLog("log", "at pages/user/user.vue:54", "用户点击取消");
            }
          }
        });
      },
      gotouser() {
        uni.navigateTo({
          url: "/pages/userupdate/userupdate"
        });
      },
      gotopass() {
        uni.navigateTo({
          url: "/pages/updatepass/updatepass"
        });
      }
    }
  };
  function _sfc_render$j(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("view", {
        class: "head",
        style: { "display": "flex", "flex-direction": "column" }
      }, [
        vue.createElementVNode("image", {
          src: `${$data.baseurl}/public/${$data.user.head}`
        }, null, 8, ["src"])
      ]),
      vue.createElementVNode("view", { class: "content" }, [
        vue.createElementVNode("view", {
          class: "content_item",
          onClick: _cache[0] || (_cache[0] = (...args) => $options.gotouser && $options.gotouser(...args))
        }, [
          vue.createElementVNode("view", { class: "content_t" }),
          vue.createElementVNode("text", { class: "text" }, "Personal Information"),
          vue.createElementVNode("image", {
            src: _imports_0$3,
            mode: ""
          })
        ]),
        vue.createElementVNode("view", {
          class: "content_item",
          onClick: _cache[1] || (_cache[1] = (...args) => $options.gotopass && $options.gotopass(...args))
        }, [
          vue.createElementVNode("view", { class: "content_t" }),
          vue.createElementVNode("text", { class: "text" }, "Change Password"),
          vue.createElementVNode("image", {
            src: _imports_0$3,
            mode: ""
          })
        ]),
        vue.createElementVNode("view", {
          class: "content_item",
          onClick: _cache[2] || (_cache[2] = (...args) => $options.exituser && $options.exituser(...args))
        }, [
          vue.createElementVNode("view", { class: "content_t" }),
          vue.createElementVNode("text", { class: "text" }, "Exit account"),
          vue.createElementVNode("image", {
            src: _imports_0$3,
            mode: ""
          })
        ])
      ])
    ]);
  }
  const PagesUserUser = /* @__PURE__ */ _export_sfc(_sfc_main$j, [["render", _sfc_render$j], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/user/user.vue"]]);
  const _imports_0$2 = "/static/serch.png";
  const _imports_1$1 = "/static/gh.png";
  const _imports_2$1 = "/static/zx.png";
  const _imports_3$1 = "/static/tx.png";
  const _imports_4 = "/static/rl.png";
  const _sfc_main$i = {
    data() {
      return {
        productlist: [],
        imgList: [
          "https://img2.baidu.com/it/u=3896501312,392323153&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1741194000&t=43719c7c0c87ee2834abada2ec1ec989",
          "https://img0.baidu.com/it/u=4182814540,3383833462&fm=253&fmt=auto&app=138&f=JPEG?w=1000&h=500"
        ],
        orderssize: 0
      };
    },
    onShow() {
      this.user = getApp().globalData.user;
      this.baseurl = getApp().globalData.text;
      this.getorders();
    },
    methods: {
      getorders: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/orders/findsize",
          data: {
            uid: that.user.id,
            state: "未诊断"
          },
          success(res) {
            formatAppLog("log", "at pages/main/main.vue:64", "size", res);
            if (res.data.code == "200") {
              that.orderssize = res.data.data;
            }
          }
        });
      },
      gotocon() {
        uni.navigateTo({
          url: "/pages/consultant/consultant"
        });
      },
      remind() {
        uni.navigateTo({
          url: "/pages/remind/remind"
        });
      },
      gotocalendar() {
        uni.navigateTo({
          url: "/pages/calendar/calendar"
        });
      },
      gotohos() {
        uni.navigateTo({
          url: "/pages/hospital/hospital"
        });
      },
      serchtap() {
        uni.navigateTo({
          url: "/pages/serch/serch"
        });
      }
    }
  };
  function _sfc_render$i(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("view", {
        class: "serch",
        onClick: _cache[0] || (_cache[0] = (...args) => $options.serchtap && $options.serchtap(...args))
      }, [
        vue.createElementVNode("image", { src: _imports_0$2 }),
        vue.createElementVNode("text", null, "搜索")
      ]),
      vue.createElementVNode("swiper", {
        "indicator-dots": "",
        autoplay: "",
        style: { "height": "200px", "margin-top": "10px" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.imgList, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("swiper-item", { key: index }, [
              vue.createElementVNode("image", {
                src: item,
                class: "slide-image"
              }, null, 8, ["src"])
            ]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]),
      vue.createElementVNode("view", { class: "item" }, [
        vue.createElementVNode("view", {
          class: "qw",
          onClick: _cache[1] || (_cache[1] = (...args) => $options.gotohos && $options.gotohos(...args)),
          style: { "margin-right": "5px" }
        }, [
          vue.createElementVNode("image", {
            src: _imports_1$1,
            mode: "heightFix"
          }),
          vue.createElementVNode("text", null, "Registration")
        ]),
        vue.createElementVNode("view", {
          class: "qw",
          onClick: _cache[2] || (_cache[2] = (...args) => $options.gotocon && $options.gotocon(...args)),
          style: { "margin-left": "5px" }
        }, [
          vue.createElementVNode("image", {
            src: _imports_2$1,
            mode: "heightFix"
          }),
          vue.createElementVNode("text", null, "Consultant")
        ])
      ]),
      vue.createElementVNode("view", { class: "item" }, [
        vue.createElementVNode("view", {
          class: "qw",
          style: { "margin-right": "5px" },
          onClick: _cache[3] || (_cache[3] = (...args) => $options.remind && $options.remind(...args))
        }, [
          vue.createElementVNode("image", {
            src: _imports_3$1,
            mode: "heightFix"
          }),
          vue.createElementVNode("text", null, "Remind")
        ]),
        vue.createElementVNode("view", {
          class: "qw",
          style: { "margin-left": "5px", "position": "relative" },
          onClick: _cache[4] || (_cache[4] = (...args) => $options.gotocalendar && $options.gotocalendar(...args))
        }, [
          vue.createElementVNode(
            "view",
            { class: "crile" },
            vue.toDisplayString($data.orderssize),
            1
            /* TEXT */
          ),
          vue.createElementVNode("image", {
            src: _imports_4,
            mode: "heightFix"
          }),
          vue.createElementVNode("text", null, "Calendar")
        ])
      ])
    ]);
  }
  const PagesMainMain = /* @__PURE__ */ _export_sfc(_sfc_main$i, [["render", _sfc_render$i], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/main/main.vue"]]);
  const _sfc_main$h = {
    data() {
      return {
        user: {
          username: "",
          pass: "",
          nickname: "",
          tel: ""
        },
        baseurl: "",
        blood: ""
      };
    },
    onLoad() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
    },
    methods: {
      regist() {
        let that = this;
        uni.request({
          url: that.baseurl + "/user/updateuser",
          data: {
            id: that.user.id,
            nickname: that.user.nickname,
            tel: that.user.tel,
            head: that.user.head
          },
          success(res) {
            formatAppLog("log", "at pages/userupdate/userupdate.vue:54", res);
            getApp().globalData.user = res.data.data;
            if (res.data.code == "200") {
              uni.showToast({
                title: "保存成功",
                duration: 2e3,
                icon: "none",
                success() {
                  uni.navigateBack();
                }
              });
            }
          }
        });
      },
      choosepic() {
        let that = this;
        formatAppLog("log", "at pages/userupdate/userupdate.vue:72", "选择照片");
        uni.chooseImage({
          count: 1,
          sizeType: ["original"],
          sourceType: ["album"],
          success(res) {
            formatAppLog("log", "at pages/userupdate/userupdate.vue:78", res);
            res.tempFilePaths;
            var tempFilePathss = res.tempFilePaths;
            formatAppLog("log", "at pages/userupdate/userupdate.vue:81", "图片" + tempFilePathss);
            that.head = tempFilePathss;
            uni.uploadFile({
              url: that.baseurl + "/upload/imagewx",
              // 后端api接口
              filePath: tempFilePathss[0],
              // uni.chooseImage函数调用后获取的本地文件路劲
              name: "file",
              //后端通过'file'获取上传的文件对象
              formData: {
                "user": "test"
              },
              success: (res2) => {
                formatAppLog("log", "at pages/userupdate/userupdate.vue:91", res2);
                that.user.head = res2.data;
              }
            });
          }
        });
      }
    }
  };
  function _sfc_render$h(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("view", { class: "head" }, [
        $data.user.head === "" ? (vue.openBlock(), vue.createElementBlock("image", {
          key: 0,
          src: _imports_0$4,
          onClick: _cache[0] || (_cache[0] = (...args) => $options.choosepic && $options.choosepic(...args))
        })) : vue.createCommentVNode("v-if", true),
        $data.user.head != "" ? (vue.openBlock(), vue.createElementBlock("image", {
          key: 1,
          src: `${$data.baseurl}/public/${$data.user.head}`,
          onClick: _cache[1] || (_cache[1] = (...args) => $options.choosepic && $options.choosepic(...args))
        }, null, 8, ["src"])) : vue.createCommentVNode("v-if", true)
      ]),
      vue.createElementVNode("view", { class: "main-mian" }, [
        vue.createElementVNode("view", null, [
          vue.createElementVNode("text", null, "NickName"),
          vue.withDirectives(vue.createElementVNode(
            "input",
            {
              type: "text",
              placeholder: "Please enter name",
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $data.user.nickname = $event),
              "placeholder-class": "placeholder"
            },
            null,
            512
            /* NEED_PATCH */
          ), [
            [vue.vModelText, $data.user.nickname]
          ])
        ]),
        vue.createElementVNode("view", null, [
          vue.createElementVNode("text", null, "Tel"),
          vue.withDirectives(vue.createElementVNode(
            "input",
            {
              type: "text",
              placeholder: "Please enter phone number",
              "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $data.user.tel = $event),
              "placeholder-class": "placeholder"
            },
            null,
            512
            /* NEED_PATCH */
          ), [
            [vue.vModelText, $data.user.tel]
          ])
        ])
      ]),
      vue.createElementVNode("button", {
        class: "btn",
        onClick: _cache[4] || (_cache[4] = (...args) => $options.regist && $options.regist(...args))
      }, "保存")
    ]);
  }
  const PagesUserupdateUserupdate = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["render", _sfc_render$h], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/userupdate/userupdate.vue"]]);
  const _sfc_main$g = {
    data() {
      return {
        user: {
          username: "",
          pass: "",
          name: "",
          post: ""
        },
        baseurl: "",
        blood: ""
      };
    },
    onLoad() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
    },
    methods: {
      regist() {
        let that = this;
        uni.request({
          url: that.baseurl + "/doctor/updateuser",
          data: {
            id: that.user.id,
            post: that.user.post,
            name: that.user.name,
            head: that.user.head,
            specialty: that.user.specialty,
            focusareas: that.user.focusareas
          },
          success(res) {
            formatAppLog("log", "at pages/doctorupdate/doctorupdate.vue:66", res);
            getApp().globalData.user = res.data.data;
            if (res.data.code == "200") {
              uni.showToast({
                title: "保存成功",
                duration: 2e3,
                icon: "none",
                success() {
                  uni.navigateBack();
                }
              });
            }
          }
        });
      },
      choosepic() {
        let that = this;
        formatAppLog("log", "at pages/doctorupdate/doctorupdate.vue:84", "选择照片");
        uni.chooseImage({
          count: 1,
          sizeType: ["original"],
          sourceType: ["album"],
          success(res) {
            formatAppLog("log", "at pages/doctorupdate/doctorupdate.vue:90", res);
            res.tempFilePaths;
            var tempFilePathss = res.tempFilePaths;
            formatAppLog("log", "at pages/doctorupdate/doctorupdate.vue:93", "图片" + tempFilePathss);
            that.head = tempFilePathss;
            uni.uploadFile({
              url: that.baseurl + "/upload/imagewx",
              // 后端api接口
              filePath: tempFilePathss[0],
              // uni.chooseImage函数调用后获取的本地文件路劲
              name: "file",
              //后端通过'file'获取上传的文件对象
              formData: {
                "user": "test"
              },
              success: (res2) => {
                formatAppLog("log", "at pages/doctorupdate/doctorupdate.vue:103", res2);
                that.user.head = res2.data;
              }
            });
          }
        });
      }
    }
  };
  function _sfc_render$g(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        vue.createElementVNode("view", { class: "head" }, [
          $data.user.head === "" ? (vue.openBlock(), vue.createElementBlock("image", {
            key: 0,
            src: _imports_0$4,
            onClick: _cache[0] || (_cache[0] = (...args) => $options.choosepic && $options.choosepic(...args))
          })) : vue.createCommentVNode("v-if", true),
          $data.user.head != "" ? (vue.openBlock(), vue.createElementBlock("image", {
            key: 1,
            src: `${$data.baseurl}/public/${$data.user.head}`,
            onClick: _cache[1] || (_cache[1] = (...args) => $options.choosepic && $options.choosepic(...args))
          }, null, 8, ["src"])) : vue.createCommentVNode("v-if", true)
        ]),
        vue.createElementVNode("view", { class: "main-mian" }, [
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "Name"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                placeholder: "Please enter name",
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $data.user.name = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.user.name]
            ])
          ]),
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "Post"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                placeholder: "Please enter post",
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $data.user.post = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.user.post]
            ])
          ]),
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "Specialty"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                placeholder: "Please enter specialty",
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => $data.user.specialty = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.user.specialty]
            ])
          ]),
          vue.createElementVNode("view", null, [
            vue.createElementVNode("text", null, "Focus Areas"),
            vue.withDirectives(vue.createElementVNode(
              "input",
              {
                type: "text",
                placeholder: "Please enter focus areas",
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => $data.user.focusareas = $event),
                "placeholder-class": "placeholder"
              },
              null,
              512
              /* NEED_PATCH */
            ), [
              [vue.vModelText, $data.user.focusareas]
            ])
          ])
        ]),
        vue.createElementVNode("button", {
          class: "btn",
          onClick: _cache[6] || (_cache[6] = (...args) => $options.regist && $options.regist(...args))
        }, "保存")
      ])
    ]);
  }
  const PagesDoctorupdateDoctorupdate = /* @__PURE__ */ _export_sfc(_sfc_main$g, [["render", _sfc_render$g], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/doctorupdate/doctorupdate.vue"]]);
  const _sfc_main$f = {
    data() {
      return {
        pass: "",
        newspass: "",
        confirmpass: "",
        user: {
          username: "",
          pass: "",
          nickname: "",
          tel: ""
        },
        baseurl: ""
      };
    },
    onLoad() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
    },
    methods: {
      save() {
        let that = this;
        if (that.pass == "") {
          uni.showToast({
            title: "请输入原密码",
            icon: "none"
          });
        } else if (that.newspass == "") {
          uni.showToast({
            title: "请输入新密码",
            icon: "none"
          });
        } else if (that.confirmpass == "") {
          uni.showToast({
            title: "请确认新密码",
            icon: "none"
          });
        } else
          ;
        formatAppLog("log", "at pages/doctorpass/doctorpass.vue:69", that.pass === that.user.pass);
        if (that.pass === that.user.pass) {
          if (that.newspass === that.confirmpass) {
            uni.request({
              url: that.baseurl + "/doctor/updatepass",
              data: {
                id: that.user.id,
                pass: that.confirmpass
              },
              success(res) {
                formatAppLog("log", "at pages/doctorpass/doctorpass.vue:79", res);
                if (res.data.code == "200") {
                  uni.showToast({
                    title: "保存成功",
                    duration: 2e3,
                    icon: "none",
                    success() {
                      uni.navigateBack();
                    }
                  });
                } else {
                  uni.showToast({
                    title: res.data.msg,
                    duration: 2e3,
                    icon: "none"
                  });
                }
              }
            });
          } else {
            uni.showToast({
              title: "两次输入的密码不一致",
              icon: "none"
            });
          }
        } else {
          uni.showToast({
            title: "原密码不正确",
            icon: "none"
          });
        }
      }
    }
  };
  function _sfc_render$f(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("view", { class: "head" }, [
        $data.user.head === "" ? (vue.openBlock(), vue.createElementBlock("image", {
          key: 0,
          src: _imports_0$4
        })) : vue.createCommentVNode("v-if", true),
        $data.user.head != "" ? (vue.openBlock(), vue.createElementBlock("image", {
          key: 1,
          src: `${$data.baseurl}public/${$data.user.head}`
        }, null, 8, ["src"])) : vue.createCommentVNode("v-if", true)
      ]),
      vue.createElementVNode("view", { class: "main-mian" }, [
        vue.createElementVNode("view", null, [
          vue.createElementVNode("text", null, "Old password"),
          vue.withDirectives(vue.createElementVNode(
            "input",
            {
              type: "text",
              placeholder: "Please enter the old password",
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $data.pass = $event),
              "placeholder-class": "placeholder"
            },
            null,
            512
            /* NEED_PATCH */
          ), [
            [vue.vModelText, $data.pass]
          ])
        ]),
        vue.createElementVNode("view", null, [
          vue.createElementVNode("text", null, "New Password"),
          vue.withDirectives(vue.createElementVNode(
            "input",
            {
              type: "text",
              placeholder: "Please enter your new password",
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $data.newspass = $event),
              "placeholder-class": "placeholder"
            },
            null,
            512
            /* NEED_PATCH */
          ), [
            [vue.vModelText, $data.newspass]
          ])
        ]),
        vue.createElementVNode("view", null, [
          vue.createElementVNode("text", null, "Confirm Password"),
          vue.withDirectives(vue.createElementVNode(
            "input",
            {
              type: "text",
              placeholder: "Please enter your confirmation password",
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $data.confirmpass = $event),
              "placeholder-class": "placeholder"
            },
            null,
            512
            /* NEED_PATCH */
          ), [
            [vue.vModelText, $data.confirmpass]
          ])
        ])
      ]),
      vue.createElementVNode("button", {
        class: "btn",
        onClick: _cache[3] || (_cache[3] = (...args) => $options.save && $options.save(...args))
      }, "保存")
    ]);
  }
  const PagesDoctorpassDoctorpass = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["render", _sfc_render$f], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/doctorpass/doctorpass.vue"]]);
  const _sfc_main$e = {
    data() {
      return {
        pass: "",
        newspass: "",
        confirmpass: "",
        user: {
          username: "",
          pass: "",
          nickname: "",
          tel: ""
        },
        baseurl: ""
      };
    },
    onLoad() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
    },
    methods: {
      save() {
        let that = this;
        if (that.pass == "") {
          uni.showToast({
            title: "请输入原密码",
            icon: "none"
          });
        } else if (that.newspass == "") {
          uni.showToast({
            title: "请输入新密码",
            icon: "none"
          });
        } else if (that.confirmpass == "") {
          uni.showToast({
            title: "请确认新密码",
            icon: "none"
          });
        } else
          ;
        formatAppLog("log", "at pages/updatepass/updatepass.vue:69", that.pass === that.user.pass);
        if (that.pass === that.user.pass) {
          if (that.newspass === that.confirmpass) {
            uni.request({
              url: that.baseurl + "/user/updatepass",
              data: {
                id: that.user.id,
                pass: that.confirmpass
              },
              success(res) {
                formatAppLog("log", "at pages/updatepass/updatepass.vue:79", res);
                if (res.data.code == "200") {
                  uni.showToast({
                    title: "保存成功",
                    duration: 2e3,
                    icon: "none",
                    success() {
                      uni.navigateBack();
                    }
                  });
                } else {
                  uni.showToast({
                    title: res.data.msg,
                    duration: 2e3,
                    icon: "none"
                  });
                }
              }
            });
          } else {
            uni.showToast({
              title: "两次输入的密码不一致",
              icon: "none"
            });
          }
        } else {
          uni.showToast({
            title: "原密码不正确",
            icon: "none"
          });
        }
      }
    }
  };
  function _sfc_render$e(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("view", { class: "head" }, [
        $data.user.head === "" ? (vue.openBlock(), vue.createElementBlock("image", {
          key: 0,
          src: _imports_0$4
        })) : vue.createCommentVNode("v-if", true),
        $data.user.head != "" ? (vue.openBlock(), vue.createElementBlock("image", {
          key: 1,
          src: `${$data.baseurl}public/${$data.user.head}`
        }, null, 8, ["src"])) : vue.createCommentVNode("v-if", true)
      ]),
      vue.createElementVNode("view", { class: "main-mian" }, [
        vue.createElementVNode("view", null, [
          vue.createElementVNode("text", null, "Old password"),
          vue.withDirectives(vue.createElementVNode(
            "input",
            {
              type: "text",
              placeholder: "Please enter the old password",
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $data.pass = $event),
              "placeholder-class": "placeholder"
            },
            null,
            512
            /* NEED_PATCH */
          ), [
            [vue.vModelText, $data.pass]
          ])
        ]),
        vue.createElementVNode("view", null, [
          vue.createElementVNode("text", null, "New Password"),
          vue.withDirectives(vue.createElementVNode(
            "input",
            {
              type: "text",
              placeholder: "Please enter your new password",
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $data.newspass = $event),
              "placeholder-class": "placeholder"
            },
            null,
            512
            /* NEED_PATCH */
          ), [
            [vue.vModelText, $data.newspass]
          ])
        ]),
        vue.createElementVNode("view", null, [
          vue.createElementVNode("text", null, "Confirm Password"),
          vue.withDirectives(vue.createElementVNode(
            "input",
            {
              type: "text",
              placeholder: "Please enter your confirmation password",
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $data.confirmpass = $event),
              "placeholder-class": "placeholder"
            },
            null,
            512
            /* NEED_PATCH */
          ), [
            [vue.vModelText, $data.confirmpass]
          ])
        ])
      ]),
      vue.createElementVNode("button", {
        class: "btn",
        onClick: _cache[3] || (_cache[3] = (...args) => $options.save && $options.save(...args))
      }, "保存")
    ]);
  }
  const PagesUpdatepassUpdatepass = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["render", _sfc_render$e], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/updatepass/updatepass.vue"]]);
  const _imports_0$1 = "/static/logo.png";
  const _sfc_main$d = {
    data() {
      return {
        title: "Hello"
      };
    },
    onLoad() {
    },
    methods: {}
  };
  function _sfc_render$d(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "content" }, [
      vue.createElementVNode("image", {
        class: "logo",
        src: _imports_0$1
      }),
      vue.createElementVNode("view", { class: "text-area" }, [
        vue.createElementVNode(
          "text",
          { class: "title" },
          vue.toDisplayString($data.title),
          1
          /* TEXT */
        )
      ])
    ]);
  }
  const PagesIndexIndex = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["render", _sfc_render$d], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/index/index.vue"]]);
  const _sfc_main$c = {
    data() {
      return {
        hoslist: []
      };
    },
    onShow() {
      this.baseurl = getApp().globalData.text;
      this.gethos();
    },
    methods: {
      xq: function(e) {
        uni.navigateTo({
          url: "/pages/section/section?item=" + JSON.stringify(e)
        });
      },
      gethos: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/hospital/findAll",
          success(res) {
            formatAppLog("log", "at pages/hospital/hospital.vue:36", res);
            if (res.data.code == "200") {
              that.hoslist = res.data.data;
            }
          }
        });
      }
    }
  };
  function _sfc_render$c(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.hoslist, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "item",
              key: index,
              onClick: ($event) => $options.xq(item)
            }, [
              vue.createElementVNode("image", {
                src: `${_ctx.baseurl}/public/${item.pic}`
              }, null, 8, ["src"]),
              vue.createElementVNode("view", { class: "con" }, [
                vue.createElementVNode(
                  "text",
                  null,
                  vue.toDisplayString(item.name),
                  1
                  /* TEXT */
                )
              ])
            ], 8, ["onClick"]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ])
    ]);
  }
  const PagesHospitalHospital = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["render", _sfc_render$c], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/hospital/hospital.vue"]]);
  const _sfc_main$b = {
    data() {
      return {
        sectionlist: []
      };
    },
    onLoad(option) {
      this.baseurl = getApp().globalData.text;
      let info = JSON.parse(option.item ? option.item : "[]");
      this.info = info;
      formatAppLog("log", "at pages/section/section.vue:28", option.title);
      this.user = getApp().globalData.user;
      this.getsection();
    },
    methods: {
      xq: function(e) {
        let that = this;
        uni.navigateTo({
          url: "/pages/doctor/doctor?item=" + JSON.stringify(e) + "&hid=" + that.info.id
        });
      },
      getsection: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/section/findAll",
          data: {
            tid: that.info.id
          },
          success(res) {
            formatAppLog("log", "at pages/section/section.vue:47", res);
            if (res.data.code == "200") {
              that.sectionlist = res.data.data;
            }
          }
        });
      }
    }
  };
  function _sfc_render$b(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        vue.createElementVNode("view", { class: "hositem" }, [
          vue.createElementVNode("image", {
            src: `${_ctx.baseurl}/public/${_ctx.info.pic}`
          }, null, 8, ["src"]),
          vue.createElementVNode("view", { class: "con" }, [
            vue.createElementVNode(
              "text",
              null,
              vue.toDisplayString(_ctx.info.name),
              1
              /* TEXT */
            )
          ])
        ]),
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.sectionlist, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "item",
              key: index,
              onClick: ($event) => $options.xq(item)
            }, vue.toDisplayString(item.name), 9, ["onClick"]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ])
    ]);
  }
  const PagesSectionSection = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$b], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/section/section.vue"]]);
  const _sfc_main$a = {
    data() {
      return {
        xzdate: "",
        xzquart: "",
        doctorlist: [],
        hid: "",
        dateList: [],
        quartList: []
      };
    },
    onLoad(option) {
      this.baseurl = getApp().globalData.text;
      let info = JSON.parse(option.item ? option.item : "[]");
      this.info = info;
      this.user = getApp().globalData.user;
      this.hid = option.hid;
      uni.setNavigationBarTitle({
        title: this.info.name
      });
    },
    onShow() {
      this.getdate();
    },
    methods: {
      xq: function(e) {
        uni.navigateTo({
          url: "/pages/doctorxq/doctorxq?item=" + JSON.stringify(e)
        });
      },
      add: function(e) {
        let that = this;
        uni.showModal({
          title: "提示",
          content: "确认预约嘛，预约日期：" + that.xzdate + ",时间段：" + that.xzquart + ",医生：" + e.name,
          success: function(res) {
            if (res.confirm) {
              uni.request({
                url: that.baseurl + "/orders/add",
                data: {
                  uid: that.user.id,
                  hid: that.hid,
                  sid: that.info.id,
                  quantum: that.xzquart,
                  date: that.xzdate,
                  hname: e.name,
                  sname: that.info.name,
                  did: e.id
                },
                success(res2) {
                  formatAppLog("log", "at pages/doctor/doctor.vue:91", res2);
                  if (res2.data.code == "200") {
                    uni.showToast({
                      title: "预约成功",
                      icon: "none",
                      success() {
                        uni.switchTab({
                          url: "/pages/main/main"
                        });
                      }
                    });
                  }
                }
              });
            } else if (res.cancel) {
              formatAppLog("log", "at pages/doctor/doctor.vue:106", "用户点击取消");
            }
          }
        });
      },
      datequart: function(e) {
        let that = this;
        this.xzquart = e;
        that.getdoctor();
      },
      dateqh: function(e) {
        let that = this;
        that.xzdate = e;
        that.getquart();
      },
      getdate: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/orders/findDate",
          success(res) {
            formatAppLog("log", "at pages/doctor/doctor.vue:127", res);
            if (res.data.code == "200") {
              that.dateList = res.data.data;
              that.xzdate = res.data.data[0].date;
              formatAppLog("log", "at pages/doctor/doctor.vue:131", "that.xzdate", that.xzdate);
              that.getquart();
            }
          }
        });
      },
      getquart: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/orders/findquart",
          data: {
            date: that.xzdate
          },
          success(res) {
            formatAppLog("log", "at pages/doctor/doctor.vue:145", res);
            if (res.data.code == "200") {
              that.quartList = res.data.data;
              that.xzquart = res.data.data[0].name;
              that.getdoctor();
            }
          }
        });
      },
      getdoctor: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/doctor/findAll",
          data: {
            sid: that.info.id,
            hid: that.hid,
            quantum: that.xzquart,
            date: that.xzdate
          },
          success(res) {
            formatAppLog("log", "at pages/doctor/doctor.vue:165", res);
            if (res.data.code == "200") {
              that.doctorlist = res.data.data;
            }
          }
        });
      }
    }
  };
  function _sfc_render$a(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", {
      class: "main",
      style: { "padding": "10px", "box-sizing": "border-box", "background-color": "#f6f6f6" }
    }, [
      vue.createElementVNode("scroll-view", {
        "scroll-x": "",
        "show-scrollbar": false,
        style: { "white-space": "nowrap" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.dateList, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "dateitem",
              key: index
            }, [
              vue.createElementVNode("view", {
                class: vue.normalizeClass(["date", [item.date === this.xzdate ? "mritem" : "ptitem"]]),
                onClick: ($event) => $options.dateqh(item.date)
              }, [
                vue.createElementVNode(
                  "text",
                  null,
                  vue.toDisplayString(item.week),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode(
                  "text",
                  null,
                  vue.toDisplayString(item.riqi),
                  1
                  /* TEXT */
                )
              ], 10, ["onClick"])
            ]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]),
      vue.createElementVNode("scroll-view", {
        "scroll-x": "",
        "show-scrollbar": false,
        style: { "white-space": "nowrap", "margin-top": "20px" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.quartList, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "quartitem",
              key: index
            }, [
              item.state === "0" ? (vue.openBlock(), vue.createElementBlock("view", {
                key: 0,
                class: "quart0"
              }, [
                vue.createElementVNode(
                  "text",
                  null,
                  vue.toDisplayString(item.name),
                  1
                  /* TEXT */
                )
              ])) : (vue.openBlock(), vue.createElementBlock("view", {
                key: 1,
                class: vue.normalizeClass(["quart", [item.name === this.xzquart ? "mrquitem" : "ptquitem"]]),
                onClick: ($event) => $options.datequart(item.name)
              }, [
                vue.createElementVNode(
                  "text",
                  null,
                  vue.toDisplayString(item.name),
                  1
                  /* TEXT */
                )
              ], 10, ["onClick"]))
            ]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]),
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "calc(100% - 200px)", "margin-top": "20px" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.doctorlist, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "doitem",
              key: index
            }, [
              vue.createElementVNode("view", {
                class: "dohead",
                onClick: ($event) => $options.xq(item)
              }, [
                vue.createElementVNode("image", {
                  src: `${_ctx.baseurl}/public/${item.head}`
                }, null, 8, ["src"])
              ], 8, ["onClick"]),
              vue.createElementVNode("view", {
                class: "docon",
                onClick: ($event) => $options.xq(item)
              }, [
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "14px", "font-weight": "600" } },
                  vue.toDisplayString(item.name),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "12px", "margin-top": "10px" } },
                  vue.toDisplayString(item.post),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "12px", "margin-top": "10px" } },
                  vue.toDisplayString(item.specialty),
                  1
                  /* TEXT */
                )
              ], 8, ["onClick"]),
              vue.createElementVNode("view", {
                style: { "margin-left": "10px" },
                class: "dobtn"
              }, [
                item.state === "1" ? (vue.openBlock(), vue.createElementBlock("view", {
                  key: 0,
                  class: "ym"
                }, "约满")) : (vue.openBlock(), vue.createElementBlock("view", {
                  key: 1,
                  onClick: ($event) => $options.add(item),
                  class: "yy"
                }, "预约", 8, ["onClick"]))
              ])
            ]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ])
    ]);
  }
  const PagesDoctorDoctor = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["render", _sfc_render$a], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/doctor/doctor.vue"]]);
  const _sfc_main$9 = {
    data() {
      return {
        info: {}
      };
    },
    onLoad(option) {
      this.baseurl = getApp().globalData.text;
      let info = JSON.parse(option.item ? option.item : "[]");
      this.info = info;
      this.user = getApp().globalData.user;
      uni.setNavigationBarTitle({
        title: this.info.name
      });
    },
    methods: {}
  };
  function _sfc_render$9(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", {
      class: "main",
      style: { "padding": "10px", "box-sizing": "border-box", "background-color": "#f6f6f6" }
    }, [
      vue.createElementVNode("view", { class: "head" }, [
        vue.createElementVNode("image", {
          src: `${_ctx.baseurl}/public/${$data.info.head}`
        }, null, 8, ["src"]),
        vue.createElementVNode("view", { class: "con" }, [
          vue.createElementVNode(
            "text",
            { style: { "font-size": "16px", "font-weight": "600" } },
            vue.toDisplayString($data.info.name),
            1
            /* TEXT */
          ),
          vue.createElementVNode(
            "text",
            { style: { "font-size": "14px", "margin-top": "10px" } },
            vue.toDisplayString($data.info.post),
            1
            /* TEXT */
          )
        ])
      ]),
      vue.createElementVNode("view", { class: "conn" }, [
        vue.createElementVNode(
          "text",
          { style: { "font-size": "14px", "margin-top": "10px" } },
          "Specialty:" + vue.toDisplayString($data.info.specialty),
          1
          /* TEXT */
        )
      ]),
      vue.createElementVNode("view", { class: "conn" }, [
        vue.createElementVNode(
          "text",
          { style: { "font-size": "14px", "margin-top": "10px" } },
          "Focus Areas:" + vue.toDisplayString($data.info.focusareas),
          1
          /* TEXT */
        )
      ])
    ]);
  }
  const PagesDoctorxqDoctorxq = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$9], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/doctorxq/doctorxq.vue"]]);
  const _sfc_main$8 = {
    data() {
      return {
        ordersList: [],
        user: {}
      };
    },
    onShow() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
      this.getorders();
      formatAppLog("log", "at pages/calendar/calendar.vue:30", "user=", this.user);
    },
    methods: {
      xq: function(e) {
        uni.navigateTo({
          url: "/pages/details/details?item=" + JSON.stringify(e)
        });
      },
      getorders: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/orders/findAll",
          data: {
            uid: that.user.id
          },
          success(res) {
            formatAppLog("log", "at pages/calendar/calendar.vue:47", res);
            if (res.data.code == "200") {
              that.ordersList = res.data.data;
            }
          }
        });
      }
    }
  };
  function _sfc_render$8(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", {
      class: "main",
      style: { "padding": "10px", "background-color": "#f6f6f6", "box-sizing": "border-box" }
    }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.ordersList, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "item",
              key: index,
              onClick: ($event) => $options.xq(item)
            }, [
              vue.createElementVNode("image", {
                src: `${_ctx.baseurl}/public/${item.head}`
              }, null, 8, ["src"]),
              vue.createElementVNode("view", { class: "con" }, [
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "14px", "font-weight": "600" } },
                  vue.toDisplayString(item.name),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "12px", "margin-top": "10px" } },
                  vue.toDisplayString(item.post),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "12px", "margin-top": "10px" } },
                  "预约日期：" + vue.toDisplayString(item.date),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "12px", "margin-top": "10px" } },
                  "预约时间段：" + vue.toDisplayString(item.quantum),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "12px", "margin-top": "10px", "color": "#F56C6C" } },
                  "状态：" + vue.toDisplayString(item.state),
                  1
                  /* TEXT */
                )
              ])
            ], 8, ["onClick"]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ])
    ]);
  }
  const PagesCalendarCalendar = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$8], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/calendar/calendar.vue"]]);
  const _sfc_main$7 = {
    data() {
      return {
        info: {}
      };
    },
    onLoad(option) {
      this.baseurl = getApp().globalData.text;
      let info = JSON.parse(option.item ? option.item : "[]");
      this.info = info;
      this.user = getApp().globalData.user;
    },
    methods: {}
  };
  function _sfc_render$7(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", {
      class: "main",
      style: { "background-color": "#f6f6f6" }
    }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        vue.createElementVNode("view", { class: "doitem" }, [
          vue.createElementVNode("view", { class: "dohead" }, [
            vue.createElementVNode("image", {
              src: `${_ctx.baseurl}/public/${$data.info.head}`
            }, null, 8, ["src"])
          ]),
          vue.createElementVNode("view", { class: "docon" }, [
            vue.createElementVNode(
              "text",
              { style: { "font-size": "14px", "font-weight": "600" } },
              vue.toDisplayString($data.info.name),
              1
              /* TEXT */
            ),
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px" } },
              vue.toDisplayString($data.info.post),
              1
              /* TEXT */
            ),
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px" } },
              vue.toDisplayString($data.info.specialty),
              1
              /* TEXT */
            )
          ])
        ]),
        vue.createElementVNode("view", { class: "doitem" }, [
          vue.createElementVNode("view", { class: "docon" }, [
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px" } },
              "科室：" + vue.toDisplayString($data.info.sname),
              1
              /* TEXT */
            ),
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px" } },
              "预约时间：" + vue.toDisplayString($data.info.date) + " " + vue.toDisplayString($data.info.quantum),
              1
              /* TEXT */
            ),
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px", "color": "#F56C6C" } },
              "状态：" + vue.toDisplayString($data.info.state),
              1
              /* TEXT */
            )
          ])
        ]),
        vue.createElementVNode("view", { class: "doitem" }, [
          vue.createElementVNode("view", { class: "docon" }, [
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px" } },
              "医院名称：" + vue.toDisplayString($data.info.hname) + vue.toDisplayString($data.info.quartum),
              1
              /* TEXT */
            ),
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px" } },
              "医院地址：" + vue.toDisplayString($data.info.address),
              1
              /* TEXT */
            )
          ])
        ]),
        $data.info.state === "已诊断" ? (vue.openBlock(), vue.createElementBlock("view", {
          key: 0,
          class: "doitem"
        }, [
          vue.createElementVNode("view", { class: "docon" }, [
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px" } },
              "diagnose：" + vue.toDisplayString($data.info.content) + vue.toDisplayString($data.info.quartum),
              1
              /* TEXT */
            ),
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px" } },
              "Drug：" + vue.toDisplayString($data.info.drug),
              1
              /* TEXT */
            )
          ])
        ])) : vue.createCommentVNode("v-if", true)
      ])
    ]);
  }
  const PagesDetailsDetails = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$7], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/details/details.vue"]]);
  const _sfc_main$6 = {
    data() {
      return {};
    },
    methods: {}
  };
  function _sfc_render$6(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view");
  }
  const PagesRemindRemind = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$6], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/remind/remind.vue"]]);
  const _imports_0 = "/static/bh.png";
  const _imports_1 = "/static/user.png";
  const _imports_2 = "/static/pass.png";
  const _imports_3 = "/static/exit2.png";
  const _sfc_main$5 = {
    data() {
      return {};
    },
    methods: {
      gotouser() {
        uni.navigateTo({
          url: "/pages/doctorupdate/doctorupdate"
        });
      },
      gotopass() {
        uni.navigateTo({
          url: "/pages/doctorpass/doctorpass"
        });
      },
      gotoexit() {
        uni.showModal({
          title: "提示",
          content: "确认退出嘛 ？",
          success: function(res) {
            if (res.confirm) {
              uni.reLaunch({
                url: "/pages/login/login"
              });
            } else if (res.cancel) {
              formatAppLog("log", "at pages/Doctormain/Doctormain.vue:56", "用户点击取消");
            }
          }
        });
      },
      patient() {
        uni.navigateTo({
          url: "/pages/patient/patient"
        });
      },
      tappatient() {
        uni.navigateTo({
          url: "/pages/allpatient/allpatient"
        });
      }
    }
  };
  function _sfc_render$5(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", {
      class: "main",
      style: { "background-color": "#f6f6f6" }
    }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        vue.createElementVNode("view", {
          class: "io",
          onClick: _cache[0] || (_cache[0] = (...args) => $options.patient && $options.patient(...args))
        }, [
          vue.createElementVNode("image", { src: _imports_0 }),
          vue.createElementVNode("text", null, "Patient of the day")
        ]),
        vue.createElementVNode("view", {
          class: "io",
          onClick: _cache[1] || (_cache[1] = (...args) => $options.tappatient && $options.tappatient(...args))
        }, [
          vue.createElementVNode("image", { src: _imports_0 }),
          vue.createElementVNode("text", null, "All patients")
        ]),
        vue.createElementVNode("view", {
          class: "io",
          onClick: _cache[2] || (_cache[2] = (...args) => $options.gotouser && $options.gotouser(...args))
        }, [
          vue.createElementVNode("image", { src: _imports_1 }),
          vue.createElementVNode("text", null, "Personal Information")
        ]),
        vue.createElementVNode("view", {
          class: "io",
          onClick: _cache[3] || (_cache[3] = (...args) => $options.gotopass && $options.gotopass(...args))
        }, [
          vue.createElementVNode("image", { src: _imports_2 }),
          vue.createElementVNode("text", null, "Change Password")
        ]),
        vue.createElementVNode("view", {
          class: "io",
          onClick: _cache[4] || (_cache[4] = (...args) => $options.gotoexit && $options.gotoexit(...args))
        }, [
          vue.createElementVNode("image", { src: _imports_3 }),
          vue.createElementVNode("text", null, "Exit account")
        ])
      ])
    ]);
  }
  const PagesDoctormainDoctormain = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$5], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/Doctormain/Doctormain.vue"]]);
  const _sfc_main$4 = {
    data() {
      return {
        doctorlist: []
      };
    },
    onLoad(option) {
    },
    onShow() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
      this.getdoctor();
    },
    methods: {
      xq: function(e) {
        uni.navigateTo({
          url: "/pages/patientdetails/patientdetails?item=" + JSON.stringify(e)
        });
      },
      getdoctor: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/orders/findDATE",
          data: {
            did: that.user.id
          },
          success(res) {
            formatAppLog("log", "at pages/patient/patient.vue:53", res);
            if (res.data.code == "200") {
              that.doctorlist = res.data.data;
            }
          }
        });
      }
    }
  };
  function _sfc_render$4(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", {
      class: "main",
      style: { "background-color": "#f6f6f6", "padding": "10px", "box-sizing": "border-box" }
    }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.doctorlist, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "doitem",
              key: index
            }, [
              vue.createElementVNode("view", {
                class: "dohead",
                onClick: ($event) => $options.xq(item)
              }, [
                vue.createElementVNode("image", {
                  src: `${_ctx.baseurl}/public/${item.uhead}`
                }, null, 8, ["src"])
              ], 8, ["onClick"]),
              vue.createElementVNode("view", {
                class: "docon",
                onClick: ($event) => $options.xq(item)
              }, [
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "14px", "font-weight": "600" } },
                  vue.toDisplayString(item.nickname),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode("view", { style: { "margin-top": "10px" } }, [
                  vue.createElementVNode(
                    "text",
                    { style: { "font-size": "12px" } },
                    "Sex：" + vue.toDisplayString(item.sex) + " Age：" + vue.toDisplayString(item.age),
                    1
                    /* TEXT */
                  )
                ]),
                vue.createElementVNode("view", { style: { "margin-top": "10px" } }, [
                  vue.createElementVNode(
                    "text",
                    { style: { "font-size": "12px" } },
                    vue.toDisplayString(item.date) + " " + vue.toDisplayString(item.quantum),
                    1
                    /* TEXT */
                  )
                ]),
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "12px", "margin-top": "10px", "color": "#F56C6C" } },
                  vue.toDisplayString(item.state),
                  1
                  /* TEXT */
                )
              ], 8, ["onClick"])
            ]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ])
    ]);
  }
  const PagesPatientPatient = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/patient/patient.vue"]]);
  const _sfc_main$3 = {
    data() {
      return {
        info: {},
        content: "",
        drug: ""
      };
    },
    onLoad(option) {
      this.baseurl = getApp().globalData.text;
      let info = JSON.parse(option.item ? option.item : "[]");
      this.info = info;
      this.content = info.content;
      this.drug = info.drug;
      this.user = getApp().globalData.user;
    },
    methods: {
      seerecord() {
        let that = this;
        uni.navigateTo({
          url: "/pages/record/record?uid=" + that.info.uid
        });
      },
      tj() {
        let that = this;
        if (that.content === "") {
          uni.showToast({
            title: "请输入诊断结果",
            icon: "none"
          });
        } else {
          uni.request({
            url: that.baseurl + "/orders/update",
            data: {
              id: that.info.id,
              content: that.content,
              drug: that.drug,
              state: "已诊断"
            },
            success(res) {
              formatAppLog("log", "at pages/patientdetails/patientdetails.vue:70", res);
              if (res.data.code == "200") {
                uni.showToast({
                  title: "诊断完成",
                  success() {
                    uni.navigateBack();
                  }
                });
              }
            }
          });
        }
      }
    }
  };
  function _sfc_render$3(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", {
      class: "main",
      style: { "background-color": "#f6f6f6", "padding": "10px", "box-sizing": "border-box" }
    }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "",
        style: { "height": "100%" }
      }, [
        vue.createElementVNode("view", { class: "doitem" }, [
          vue.createElementVNode("view", {
            class: "dohead",
            onClick: _cache[0] || (_cache[0] = ($event) => _ctx.xq(_ctx.item))
          }, [
            vue.createElementVNode("image", {
              src: `${_ctx.baseurl}/public/${$data.info.uhead}`
            }, null, 8, ["src"])
          ]),
          vue.createElementVNode("view", {
            class: "docon",
            onClick: _cache[1] || (_cache[1] = ($event) => _ctx.xq(_ctx.item))
          }, [
            vue.createElementVNode(
              "text",
              { style: { "font-size": "14px", "font-weight": "600" } },
              vue.toDisplayString($data.info.nickname),
              1
              /* TEXT */
            ),
            vue.createElementVNode("view", { style: { "margin-top": "10px" } }, [
              vue.createElementVNode(
                "text",
                { style: { "font-size": "12px" } },
                "Sex：" + vue.toDisplayString($data.info.sex) + " Age：" + vue.toDisplayString($data.info.age),
                1
                /* TEXT */
              )
            ]),
            vue.createElementVNode("view", { style: { "margin-top": "10px" } }, [
              vue.createElementVNode(
                "text",
                { style: { "font-size": "12px" } },
                vue.toDisplayString($data.info.date) + " " + vue.toDisplayString($data.info.quantum),
                1
                /* TEXT */
              )
            ]),
            vue.createElementVNode(
              "text",
              { style: { "font-size": "12px", "margin-top": "10px", "color": "#F56C6C" } },
              vue.toDisplayString($data.info.state),
              1
              /* TEXT */
            )
          ])
        ]),
        vue.withDirectives(vue.createElementVNode(
          "textarea",
          {
            placeholder: "Please enter diagnosis",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $data.content = $event)
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [vue.vModelText, $data.content]
        ]),
        vue.withDirectives(vue.createElementVNode(
          "textarea",
          {
            placeholder: "Please enter the prescription record",
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $data.drug = $event)
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [vue.vModelText, $data.drug]
        ]),
        vue.createElementVNode("button", {
          class: "tjbtn",
          onClick: _cache[4] || (_cache[4] = (...args) => $options.tj && $options.tj(...args))
        }, "提交"),
        vue.createElementVNode("button", {
          class: "seerecord",
          onClick: _cache[5] || (_cache[5] = (...args) => $options.seerecord && $options.seerecord(...args))
        }, "查看就诊记录")
      ])
    ]);
  }
  const PagesPatientdetailsPatientdetails = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/patientdetails/patientdetails.vue"]]);
  const _sfc_main$2 = {
    data() {
      return {
        doctorlist: []
      };
    },
    onLoad(option) {
    },
    onShow() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
      this.getdoctor();
    },
    methods: {
      xq: function(e) {
        uni.navigateTo({
          url: "/pages/patientdetails/patientdetails?item=" + JSON.stringify(e)
        });
      },
      getdoctor: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/orders/findAll",
          data: {
            did: that.user.id
          },
          success(res) {
            formatAppLog("log", "at pages/allpatient/allpatient.vue:53", res);
            if (res.data.code == "200") {
              that.doctorlist = res.data.data;
            }
          }
        });
      }
    }
  };
  function _sfc_render$2(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", {
      class: "main",
      style: { "background-color": "#f6f6f6", "padding": "10px", "box-sizing": "border-box" }
    }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.doctorlist, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "doitem",
              key: index
            }, [
              vue.createElementVNode("view", {
                class: "dohead",
                onClick: ($event) => $options.xq(item)
              }, [
                vue.createElementVNode("image", {
                  src: `${_ctx.baseurl}/public/${item.uhead}`
                }, null, 8, ["src"])
              ], 8, ["onClick"]),
              vue.createElementVNode("view", {
                class: "docon",
                onClick: ($event) => $options.xq(item)
              }, [
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "14px", "font-weight": "600" } },
                  vue.toDisplayString(item.nickname),
                  1
                  /* TEXT */
                ),
                vue.createElementVNode("view", { style: { "margin-top": "10px" } }, [
                  vue.createElementVNode(
                    "text",
                    { style: { "font-size": "12px" } },
                    "Sex：" + vue.toDisplayString(item.sex) + " Age：" + vue.toDisplayString(item.age),
                    1
                    /* TEXT */
                  )
                ]),
                vue.createElementVNode("view", { style: { "margin-top": "10px" } }, [
                  vue.createElementVNode(
                    "text",
                    { style: { "font-size": "12px" } },
                    vue.toDisplayString(item.date) + " " + vue.toDisplayString(item.quantum),
                    1
                    /* TEXT */
                  )
                ]),
                vue.createElementVNode(
                  "text",
                  { style: { "font-size": "12px", "margin-top": "10px", "color": "#F56C6C" } },
                  vue.toDisplayString(item.state),
                  1
                  /* TEXT */
                )
              ], 8, ["onClick"])
            ]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ])
    ]);
  }
  const PagesAllpatientAllpatient = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/allpatient/allpatient.vue"]]);
  const _sfc_main$1 = {
    data() {
      return {
        uid: "",
        doctorlist: []
      };
    },
    onLoad(option) {
      this.baseurl = getApp().globalData.text;
      this.uid = option.uid;
      this.user = getApp().globalData.user;
      this.getdoctor();
    },
    methods: {
      getdoctor: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/orders/findAll",
          data: {
            uid: that.uid,
            state: "已诊断"
          },
          success(res) {
            formatAppLog("log", "at pages/record/record.vue:39", res);
            if (res.data.code == "200") {
              that.doctorlist = res.data.data;
            }
          }
        });
      }
    }
  };
  function _sfc_render$1(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "100%", "background-color": "#f6f6f6", "padding": "10px", "box-sizing": "border-box" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.doctorlist, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              class: "item",
              key: index
            }, [
              vue.createElementVNode(
                "text",
                null,
                "Section：" + vue.toDisplayString(item.sname),
                1
                /* TEXT */
              ),
              vue.createElementVNode(
                "text",
                null,
                "Diagnosis：" + vue.toDisplayString(item.content),
                1
                /* TEXT */
              ),
              vue.createElementVNode(
                "text",
                null,
                "Drug：" + vue.toDisplayString(item.drug),
                1
                /* TEXT */
              ),
              vue.createElementVNode(
                "text",
                null,
                "Date：" + vue.toDisplayString(item.date),
                1
                /* TEXT */
              )
            ]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ])
    ]);
  }
  const PagesRecordRecord = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/record/record.vue"]]);
  const _sfc_main = {
    data() {
      return {
        content: "",
        infoList: [],
        user: {}
      };
    },
    onShow() {
      this.baseurl = getApp().globalData.text;
      this.user = getApp().globalData.user;
      this.getinfo();
    },
    methods: {
      getinfo: function() {
        let that = this;
        uni.request({
          url: that.baseurl + "/chat/findAll",
          data: {
            uid: that.user.id,
            did: "1"
          },
          success(res) {
            if (res.data.code == "200") {
              that.infoList = res.data.data;
            }
          }
        });
      },
      fs: function() {
        let that = this;
        if (that.content === "") {
          uni.showToast({
            title: "请输入内容",
            icon: "none"
          });
        } else {
          uni.request({
            url: that.baseurl + "/chat/add",
            data: {
              uid: that.user.id,
              did: "1",
              content: that.content
            },
            success(res) {
              if (res.data.code == "200") {
                wx.showToast({
                  title: "发送中",
                  duration: 3e3,
                  icon: "loading",
                  success: function() {
                    setTimeout(function() {
                      wx.showToast({
                        title: "发送成功",
                        success: function() {
                          setTimeout(function() {
                            that.content = "";
                            that.getinfo();
                          }, 1e3);
                        }
                      });
                    }, 1e3);
                  }
                });
              } else {
                uni.showToast({
                  title: res.data.msg,
                  icon: "none"
                });
              }
            }
          });
        }
      }
    }
  };
  function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
    return vue.openBlock(), vue.createElementBlock("view", { class: "main" }, [
      vue.createElementVNode("scroll-view", {
        "scroll-y": "true",
        style: { "height": "85%" }
      }, [
        (vue.openBlock(true), vue.createElementBlock(
          vue.Fragment,
          null,
          vue.renderList($data.infoList, (item, index) => {
            return vue.openBlock(), vue.createElementBlock("view", {
              key: index,
              class: "wdmsg"
            });
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]),
      vue.createElementVNode("view", {
        class: "btoview",
        style: {}
      }, [
        vue.withDirectives(vue.createElementVNode(
          "input",
          {
            placeholder: "请输入内容",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $data.content = $event)
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [vue.vModelText, $data.content]
        ]),
        vue.createElementVNode("view", {
          onClick: _cache[1] || (_cache[1] = (...args) => $options.fs && $options.fs(...args))
        }, "发送")
      ])
    ]);
  }
  const PagesConsultantConsultant = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "D:/Work/HBuilderProjects/hospital/hospital/pages/consultant/consultant.vue"]]);
  __definePage("pages/login/login", PagesLoginLogin);
  __definePage("pages/regist/regist", PagesRegistRegist);
  __definePage("pages/user/user", PagesUserUser);
  __definePage("pages/main/main", PagesMainMain);
  __definePage("pages/userupdate/userupdate", PagesUserupdateUserupdate);
  __definePage("pages/doctorupdate/doctorupdate", PagesDoctorupdateDoctorupdate);
  __definePage("pages/doctorpass/doctorpass", PagesDoctorpassDoctorpass);
  __definePage("pages/updatepass/updatepass", PagesUpdatepassUpdatepass);
  __definePage("pages/index/index", PagesIndexIndex);
  __definePage("pages/hospital/hospital", PagesHospitalHospital);
  __definePage("pages/section/section", PagesSectionSection);
  __definePage("pages/doctor/doctor", PagesDoctorDoctor);
  __definePage("pages/doctorxq/doctorxq", PagesDoctorxqDoctorxq);
  __definePage("pages/calendar/calendar", PagesCalendarCalendar);
  __definePage("pages/details/details", PagesDetailsDetails);
  __definePage("pages/remind/remind", PagesRemindRemind);
  __definePage("pages/Doctormain/Doctormain", PagesDoctormainDoctormain);
  __definePage("pages/patient/patient", PagesPatientPatient);
  __definePage("pages/patientdetails/patientdetails", PagesPatientdetailsPatientdetails);
  __definePage("pages/allpatient/allpatient", PagesAllpatientAllpatient);
  __definePage("pages/record/record", PagesRecordRecord);
  __definePage("pages/consultant/consultant", PagesConsultantConsultant);
  function createApp() {
    const app = vue.createVueApp(App);
    return {
      app
    };
  }
  const { app: __app__, Vuex: __Vuex__, Pinia: __Pinia__ } = createApp();
  uni.Vuex = __Vuex__;
  uni.Pinia = __Pinia__;
  __app__.provide("__globalStyles", __uniConfig.styles);
  __app__._component.mpType = "app";
  __app__._component.render = () => {
  };
  __app__.mount("#app");
})(Vue);
