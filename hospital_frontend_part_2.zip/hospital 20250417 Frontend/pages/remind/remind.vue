<template>
	<view class="main">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="item" v-for="(item, index) in remindlist" :key="index"  @click="xq(item)">
					<text>{{item.reminder}}</text>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				remindlist:[]
			}
		},
		onShow() {
			this.baseurl = getApp().globalData.text;
			this.getremind()
		},
		methods: {
			xq:function(e){
				uni.navigateTo({
					url:"/pages/remindxq/remindxq?item="+JSON.stringify(e)
				})
			},
			change:function(e){
				console.log('e',e);
			},
			getremind:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/remind/findAll',
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.remindlist=res.data.data
						}
					}
				})
			},
		}
	}
</script>

<style>
	.item{
		width: calc(100% - 20px);
		background-color: #fff;
		height: 50px;
		margin: 10px;
		display: flex;
		align-items: center;
		justify-content: space-between;
		border-radius: 10px;
		padding-left: 10px;
		padding-right: 10px;
		box-sizing: border-box;
	}
	page{
		
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
			width: 100%;
			height: 100%;
			display: flex;
			flex-direction: column;
			background-color: #f6f6f6;
		}

</style>
