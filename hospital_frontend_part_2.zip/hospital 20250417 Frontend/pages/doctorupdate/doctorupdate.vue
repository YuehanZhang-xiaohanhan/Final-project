<template>
	<view class="main">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="head">
					<image v-if="user.head === ''"  src="../../static/head.png"  @click="choosepic"></image>
				<image v-if="user.head != ''" :src="`${baseurl}/public/${user.head}`"  @click="choosepic"></image>
				
			</view>
			<view class="main-mian">
				<view >
					<text>Name</text>
					<input type="text" placeholder="Please enter name" v-model="user.name" placeholder-class="placeholder">
				</view>
				<view>
					<text>Post</text>
					<input type="text" placeholder="Please enter post" v-model="user.post" placeholder-class="placeholder">
				</view>
				<view>
					<text>Specialty</text>
					<input type="text" placeholder="Please enter specialty" v-model="user.specialty" placeholder-class="placeholder">
				</view>
				<view>
					<text>Focus Areas</text>
					<input type="text" placeholder="Please enter focus areas" v-model="user.focusareas" placeholder-class="placeholder">
				</view>
			</view>
			<button class="btn" @click="regist">保存</button>
		</scroll-view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				user:{
					username :'',
					pass:'',
					name:'',
					post:'',
				},
				baseurl:'',
				blood:''
			}
		},
		onLoad() {
			this.baseurl = getApp().globalData.text;
			this.user = getApp().globalData.user;
		},
		methods: {
			
			regist(){
				let that = this;
					uni.request({
						url:that.baseurl+'/doctor/updateuser',
						data:{
							id:that.user.id,
							post:that.user.post,
							name:that.user.name,
							head:that.user.head,
							specialty:that.user.specialty,
							focusareas:that.user.focusareas,
						},
						success(res) {
							console.log(res)
							getApp().globalData.user = res.data.data
							if(res.data.code == '200'){
								uni.showToast({
								  title: '保存成功',
								  duration:2000,
								  icon:'none',
								  success() {
								  	uni.navigateBack()
								  }
								})
							}
						}
					})
			},
			
			choosepic(){
				let that = this;
				console.log('选择照片')
				uni.chooseImage({
					count:1,
					sizeType: ['original'],
					sourceType: ['album'],
					success(res) {
						console.log(res)
						const tempFilePaths = res.tempFilePaths;
						var tempFilePathss = res.tempFilePaths;
						console.log("图片"+tempFilePathss)
						that.head =tempFilePathss;
						uni.uploadFile({
						    url:that.baseurl+'/upload/imagewx',     // 后端api接口
						    filePath: tempFilePathss[0], // uni.chooseImage函数调用后获取的本地文件路劲
						    name:'file',     //后端通过'file'获取上传的文件对象
						    formData: {
								 'user': 'test'
							},
						    success:(res) => {
						        console.log(res)
								that.user.head = res.data
						    }
						});
					}
					
					
				})
				
			},
			
		}
	}
</script>

<style>
	page{
		width: 100%;
		height: 100%;
	}
	.main{
		width: 100%;
		height: 100%;
		background-color: white;
	}
	.head{
		width: 100%;
		height: 150px;
		display: flex;
		justify-content: center;
		background-color: #3282b8;
		align-items: center;
	}
	.head image{
		width: 100px;
		height: 100px;
		border-radius: 50px;
	}
	.main-mian{
		width: calc(100% - 80rpx);
		height: 60%;
		margin: 40rpx;
		display: flex;
		flex-direction: column;
	}
	.main-mian view{
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.main-mian view input{
		margin-top: 5rpx;
		border-bottom: 1px solid #f2f2f2;
	}
	.btn{
		width: 360rpx;
		background-color: #3282b8;
		border-radius: 40rpx;
		color: #fff;
	}


</style>
