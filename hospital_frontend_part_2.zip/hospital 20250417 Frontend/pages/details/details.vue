<template>
	<view class="main" style="background-color: #f6f6f6;">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="doitem" >
				<view class="dohead" >
					<image :src="`${baseurl}/public/${info.head}`" ></image>
				</view>
				<view class="docon" >
					<text style="font-size: 14px;font-weight: 600;">{{info.name}}</text>
					<text style="font-size: 12px;margin-top: 10px;">{{info.post}}</text>
					<text style="font-size: 12px;margin-top: 10px;">{{info.specialty}}</text>
				</view>
				
			</view>
			<view class="doitem" >
				<view class="docon" >
					<text style="font-size: 12px;margin-top: 10px;">科室：{{info.sname}}</text>
					<text style="font-size: 12px;margin-top: 10px;">预约时间：{{info.date}}   {{info.quantum}}</text>
					<text style="font-size: 12px;margin-top: 10px;color: #F56C6C;">状态：{{info.state}}</text>
				</view>
				
			</view>
			<view class="doitem" >
				<view class="docon" >
					<text style="font-size: 12px;margin-top: 10px;">医院名称：{{info.hname}}{{info.quartum}}</text>
					<text style="font-size: 12px;margin-top: 10px;">医院地址：{{info.address}}</text>
				</view>
				
			</view>
			<view class="doitem" v-if="info.state === '已诊断'">
				<view class="docon" >
					<text style="font-size: 12px;margin-top: 10px;">diagnose：{{info.content}}{{info.quartum}}</text>
					<text style="font-size: 12px;margin-top: 10px;">Drug：{{info.drug}}</text>
				</view>
				
			</view>
		</scroll-view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				info:{}
			}
		},
		onLoad(option) {
			this.baseurl = getApp().globalData.text;
			let info= JSON.parse(option.item ? option.item : '[]');
			this.info = info
			this.user = getApp().globalData.user;
		},
		methods: {
			
		}
	}
</script>

<style>
	.ym{
		width: 60px;
		height: 30px;
		background-color: #f6f6f6;
		color: #000;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		border-radius: 10px;
	}
	.yy{
		width: 60px;
		height: 30px;
		background-color: #1296db;
		color: #fff;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		border-radius: 10px;
	}
	.dobtn{
		height: 100%;
		display: flex;
		align-items: flex-end;
		flex-direction: column;
		justify-content: flex-end;
	}
	
	.docon{
		flex: 1;
		display: flex;
		flex-direction: column;
	}
	.dohead{
		width: 80px;
		
	}
	.dohead image{
		width: 70px;
		height: 70px;
		border-radius: 50%;
	}
	.doitem{
		width: calc(100% - 20px);
		height: auto;
		background-color: #fff;
		margin: 10px;
		display: flex;
		padding: 10px;
		box-sizing: border-box;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.item{
		width: calc(100% - 20px);
		height: auto;
		min-height: 100px;
		background-color: #fff;
		margin: 10px;
		border-radius: 6px;
		padding: 10px;
		box-sizing: border-box;
	}

</style>
