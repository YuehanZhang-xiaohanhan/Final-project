<template>
	<view class="op">
		<text>提醒时间：{{info.reminder}}</text>
		<view style="height: 20px;"></view>
		<switch v-if="info.status === '1'" checked @change="switchChange" />
		<switch v-if="info.status === '0'"  @change="switchChange" />
		<button type="primary" style="width: 50%;margin-top: 20px;" @click="adds">提交</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				info:'',
			}
		},
		onLoad(option) {
			this.baseurl = getApp().globalData.text;
			let info= JSON.parse(option.item ? option.item : '[]');
			this.info = info
			this.user = getApp().globalData.user;
			
		},
		methods: {
			switchChange:function(e){
				let that = this
				console.log('e',e);
				if(e.detail.value){
					console.log('开启');
					that.info.status = '1'
				}
				else{
					console.log('关闭');
					that.info.status = '0'
				}
			},
			adds:function(){
				let that = this
				uni.request({
					url:that.baseurl+'/remind/update',
					data:{
						id:that.info.id,
						status:that.info.status,
					},
					success(res) {
						console.log(res)
						if(res.data.code == '200'){
							uni.showToast({
							  title: '成功',
							  duration:2000,
							  icon:'success',
							  success() {
							  	  uni.navigateBack({ changed: true });
							  }
							})
						}
						else{
							uni.showToast({
							  title: res.data.msg,
							  duration:2000,
							  icon:'none'
							  
							})
							
						}
					}
				})
			},
			
		}
	}
</script>

<style>
	.op{
		
		width: 100%;
		height: auto;
		display: flex;
		flex-direction: column;
		padding: 20px;
		box-sizing: border-box;
	}

</style>
