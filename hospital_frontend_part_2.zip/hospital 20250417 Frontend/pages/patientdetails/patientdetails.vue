<template>
	<view class="main"  style="background-color: #f6f6f6;padding: 10px;box-sizing: border-box;">
		<scroll-view scroll-y style="height: 100%;">
			<view class="doitem" >
				<view class="dohead" @click="xq(item)">
					<image :src="`${baseurl}/public/${info.uhead}`" ></image>
				</view>
				<view class="docon" @click="xq(item)">
					<text style="font-size: 14px;font-weight: 600;">{{info.nickname}}</text>
					<view style="margin-top: 10px;">
						<text style="font-size: 12px;">Sex：{{info.sex}}  Age：{{info.age}}</text>
					</view>
					<view style="margin-top: 10px;">
						<text style="font-size: 12px;">{{info.date}} {{info.quantum}}</text>
					</view>
					<text style="font-size: 12px;margin-top: 10px;color: #F56C6C;">{{info.state}}</text>
				</view>
			</view>
			<textarea placeholder="Please enter diagnosis"  v-model="content"></textarea>
			<textarea placeholder="Please enter the prescription record"  v-model="drug"></textarea>
			<button class="tjbtn" @click="tj">提交</button>
			<button class="seerecord" @click="seerecord">查看就诊记录</button>
		</scroll-view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				info:{},
				content:'',
				drug:''
			}
		},
		onLoad(option) {
			this.baseurl = getApp().globalData.text;
			let info= JSON.parse(option.item ? option.item : '[]');
			this.info = info
			this.content = info.content
			this.drug = info.drug
			this.user = getApp().globalData.user;
		},
		methods: {
			seerecord(){
				let that = this
				uni.navigateTo({
					url:'/pages/record/record?uid='+that.info.uid
				})
			},
			tj(){
				let that = this
				if(that.content === '' ){
					uni.showToast({
						title:'请输入诊断结果',
						icon:'none'
					})
				}
				else{
					uni.request({
						url:that.baseurl+'/orders/update',
						data:{
							id:that.info.id,
							content:that.content,
							drug:that.drug,
							state:'已诊断'
						},
						success(res) {
							console.log(res)
							if(res.data.code =='200'){
								uni.showToast({
									title:'诊断完成',
									success() {
										uni.navigateBack()
									}
								})
							}
						}
					})
				}
			}
			
		}
	}
</script>

<style>
	.seerecord{
		background-color: #E6A23C;
		color: #fff;
		margin-top: 20px;
	}
	.tjbtn{
		background-color: #409EFF;
		color: #fff;
		margin-top: 20px;
	}
	textarea{
		width:100%;
		border: 2px solid #409EFF;
		background-color: #fff;
		padding: 10px;
		box-sizing: border-box;
		border-radius: 10px;
		margin-top: 10px;
	}
page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.docon{
		flex: 1;
		display: flex;
		flex-direction: column;
	}
	.dohead{
		width: 80px;
		
	}
	.dohead image{
		width: 70px;
		height: 70px;
		border-radius: 50%;
	}
	.doitem{
		width: calc(100% - 20px);
		height: 140px;
		background-color: #fff;
		margin: 10px;
		display: flex;
		padding: 10px;
		box-sizing: border-box;
	}
</style>
