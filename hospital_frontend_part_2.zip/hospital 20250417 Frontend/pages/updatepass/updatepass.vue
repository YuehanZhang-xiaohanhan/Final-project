<template>
	<view class="main">
		<view class="head">
				<image v-if="user.head === ''"  src="../../static/head.png" ></image>
			<image v-if="user.head != ''" :src="`${baseurl}public/${user.head}`"  ></image>
		</view>
		<view class="main-mian">
			
			<view >
				<text>Old password</text>
				<input type="text" placeholder="Please enter the old password" v-model="pass" placeholder-class="placeholder">
				
			</view>
			<view >
				<text>New Password</text>
				<input type="text" placeholder="Please enter your new password" v-model="newspass" placeholder-class="placeholder">
			</view>
			<view >
				<text>Confirm Password</text>
				<input type="text" placeholder="Please enter your confirmation password" v-model="confirmpass" placeholder-class="placeholder">
			</view>
			
		</view>
		<button class="btn" @click="save">save</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				pass:'',
				newspass:'',
				confirmpass:'',
				user:{
					username :'',
					pass:'',
					nickname:'',
					tel:'',
				},
				baseurl:''
			}
		},
		onLoad() {
			this.baseurl = getApp().globalData.text;
			this.user = getApp().globalData.user;
		},
		methods: {
			save(){
				let that = this;
				if(that.pass==''){
					uni.showToast({
							title:'请输入原密码',
							icon:'none'
						})
				}else if(that.newspass==''){
					uni.showToast({
							title:'请输入新密码',
							icon:'none'
						})
				}else if(that.confirmpass==''){
					uni.showToast({
							title:'请确认新密码',
							icon:'none'
						})
				}
				else{
				}
				console.log(that.pass===that.user.pass);
				if(that.pass===that.user.pass){
					if(that.newspass===that.confirmpass){
						uni.request({
							url:that.baseurl+'/user/updatepass',
							data:{
								id:that.user.id,
								pass:that.confirmpass,
							},
							success(res) {
								console.log(res)
								if(res.data.code == '200'){
									uni.showToast({
									  title: '保存成功',
									  duration:2000,
									  icon:'none',
									  success() {
									  	uni.navigateBack()
									  }
									})
								}
								else{
									uni.showToast({
									  title: res.data.msg,
									  duration:2000,
									  icon:'none',
									  
									})
								}
							}
						})
					}
					else{
						uni.showToast({
							title:'两次输入的密码不一致',
							icon:'none'
						})
					}
				}else{
					uni.showToast({
						title:'原密码不正确',
						icon:'none'
					})
				}
			},
		}
	}
</script>

<style>
	page{
		width: 100%;
		height: 100%;
	}
	.main{
		width: 100%;
		height: 100%;
		background-color: white;
	}
	.head{
		width: 100%;
		height: 150px;
		background-color: #3282b8;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.head image{
		width: 100px;
		height: 100px;
		border-radius: 50px;
	}
	.main-mian{
		width: calc(100% - 80rpx);
		height: 40%;
		margin: 40rpx;
		display: flex;
		flex-direction: column;
	}
	.main-mian view{
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.main-mian view input{
		margin-top: 5rpx;
		border-bottom: 1px solid #f2f2f2;
	}
	.btn{
		width: 360rpx;
		background-color: #3282b8;
		border-radius: 40rpx;
		color: #fff;
	}


</style>
