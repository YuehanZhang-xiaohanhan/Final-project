<template>
	<view class="main">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="item" v-for="(item, index) in hoslist" :key="index"  @click="xq(item)">
				<image :src="`${baseurl}/public/${item.pic}`" ></image>
				<view class="con">
					<text>{{item.name}}</text>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				hoslist:[]
			}
		},
		onShow() {
			this.baseurl = getApp().globalData.text;
			this.gethos()
		},
		methods: {
			xq:function(e){
				uni.navigateTo({
					url:"/pages/section/section?item="+JSON.stringify(e)
				})
			},
			gethos:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/hospital/findAll',
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.hoslist=res.data.data
						}
					}
				})
			},
		}
	}
</script>

<style>
	.con{
		width: calc(100% - 170px);
		margin-left: 10px;
	}
	image{
		height: 100%;
		width: 160px;
	}
	.item{
		width: calc(100% - 20px);
		height: 160px;
		margin: 10px;
		background-color: #fff;
		padding: 10px;
		box-sizing: border-box;
		display: flex;
	}
.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		background-color: #f6f6f6;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
</style>
