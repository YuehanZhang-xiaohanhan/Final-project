<template>
	<view class="main" style="padding: 10px;background-color: #f6f6f6;box-sizing: border-box;">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="item" v-for="(item, index) in ordersList" :key="index" @click="xq(item)">
				<image :src="`${baseurl}/public/${item.head}`" ></image>
				<view class="con">
					<text style="font-size: 14px;font-weight: 600;">{{item.name}}</text>
					<text style="font-size: 12px;margin-top: 10px;">{{item.post}}</text>
					<text style="font-size: 12px;margin-top: 10px;">Booking Date 
：{{item.date}}</text>
					<text style="font-size: 12px;margin-top: 10px;">Booking period：{{item.quantum}}</text>
					<text style="font-size: 12px;margin-top: 10px;color: #F56C6C;">state：{{item.state}}</text>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ordersList:[],
				user:{}
			}
		},
		onShow() {
			this.baseurl = getApp().globalData.text;
			this.user = getApp().globalData.user;
			this.getorders()
			console.log('user=',this.user);
			
		},
		methods: {
			xq:function(e){
				uni.navigateTo({
					url:"/pages/details/details?item="+JSON.stringify(e)
				})
			},
			getorders:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/orders/findAll',
					data:{
						uid:that.user.id
					},
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.ordersList=res.data.data
						}
					}
				})
			},
		}
	}
</script>

<style>
	.con{
		width: calc(100% - 90px);
		margin-left: 10px;
		display: flex;
		flex-direction: column;
	}
	image{
		width: 80px;
		height: 80px;
		border-radius: 50%;
	}
	.item{
		width: calc(100% - 20px);
		height: 140px;
		background-color: #fff;
		display: flex;
		margin: 10px;
		padding: 10px;
		box-sizing: border-box;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}

</style>
