<template>
	<view class="main">
		<view class="serch" @click="serchtap">
			<image src="/static/serch.png"></image>
			<text>search</text>
		</view>
		<swiper indicator-dots autoplay style="height: 200px;margin-top: 10px;">
		      <swiper-item v-for="(item, index) in imgList" :key="index">
		        <image :src="item" class="slide-image"></image>
		      </swiper-item>
		</swiper>
		<view class="item">
			<view class="qw" @click="gotohos" style="margin-right: 5px;">
				<image src="/static/gh.png" mode="heightFix"></image>
				<text>Registration</text>
			</view>
			<view class="qw" @click="gotocon"  style="margin-left: 5px;" >
				<image src="/static/zx.png" mode="heightFix"></image>
				<text>Consultant</text>
			</view>
		</view>
		<view class="item">
			<view class="qw" style="margin-right: 5px;" @click="remind">
				<image src="/static/tx.png" mode="heightFix"></image>
				<text>Remind</text>
			</view>
			<view class="qw" style="margin-left: 5px; position: relative; " @click="gotocalendar">
				<view class="crile">{{orderssize}}</view>
				<image src="/static/rl.png" mode="heightFix"></image>
				<text>Calendar</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				productlist:[],
				imgList: [
				       'https://www.cidrap.umn.edu/sites/default/files/neisseria_mening_0.jpg',
				       'https://pic.rmb.bdstatic.com/bjh/3f117d02dabe/240823/816efaf397a2e4b79610f46d8d46b3c0.png',
				],
				orderssize:0,
				 timer: ''
			}
		},
		onShow() {
			this.user = getApp().globalData.user;
			this.baseurl = getApp().globalData.text;
			this.getorders();
			 this.starttimer()
			
		},
		methods: {
			starttimer(){
				var that = this
			    that.timer = setInterval(() => {
			      that.countDown()
			    }, 10000)
			  },
			  countDown(){
			    var that = this;
			    uni.request({
			      url: that.baseurl+'/remind/findAret',
			      success(res){
			        if(res.data.code === '300'){
			          uni.showModal({
			            title: '提示',
			            content: '记得吃药',
			            success: function (res) {
			              if (res.confirm) {
			                console.log('用户点击确定');
			                // 用户点击确定后的逻辑处理
			              } else if (res.cancel) {
			                console.log('用户点击取消');
			                // 用户点击取消后的逻辑处理
			              }
			            },
			            fail: function (err) {
			              console.error('弹窗失败', err);
			              // 弹窗失败的错误处理
			            }
			          });
			          
			        }
			      }
			    })
			  },
			getorders:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/orders/findsize',
					data:{
						uid:that.user.id,
						state:'未诊断'
					},
					success(res) {
						console.log('size',res)
						if(res.data.code =='200'){
							that.orderssize=res.data.data
						}
					}
				})
			},
			gotocon(){
				uni.navigateTo({
					url:'/pages/consultant/consultant'
				})
			},
			remind(){
				uni.navigateTo({
					url:'/pages/remind/remind'
				})
			},
			gotocalendar(){
				uni.navigateTo({
					url:'/pages/calendar/calendar'
				})
			},
			gotohos(){
				uni.navigateTo({
					url:'/pages/hospital/hospital'
				})
			},
			serchtap(){
				uni.navigateTo({
					url:'/pages/search/search'
				})
			},
			
		}
	}
</script>

<style>
	.crile{
		background-color: #ff0000;
		padding: 2px 6px;
		border-radius: 50%;
		font-size: 14px;
		color: #fff;
		position: absolute;
		top:10px;
		left: 30px;
		z-index: 10;
	}
	.item{
		width: 94%;
		margin-left: 3%;
		height: 120px;
		margin-top: 10px;
		display: flex;
	}
	.qw{
		flex: 1;
		height: 100%;
		background-color: #fff;
		border-radius: 10px;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
	}
	.qw text{
		margin-top: 5px;
	}
	.qw image{
		height: 60px;
		width: 60px;
	}
	.slide-image {
	  width: 100%;
	  height: 400rpx;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		background-color: #f6f6f6;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.serch image{
		width: 25px;
		height: 25px;
	}
	.serch text{
		font-size: 14px;
	}
	.serch{
		width: 90%;
		height: 40px;
		border: 1px solid #3282b8;
		background-color: #fff;
		border-radius: 220px;
		margin-left: 5%;
		display: flex;
		align-items: center;
		justify-content: center;
	}
</style>
