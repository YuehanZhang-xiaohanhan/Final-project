<template>
	<view class="main">
		<scroll-view scroll-y="true" style="height: 100%;background-color: #f6f6f6;padding: 10px;box-sizing: border-box;">
			<view class="item" v-for="(item, index) in doctorlist" :key="index">
				<text>Section：{{item.sname}}</text>
				<text>Diagnosis：{{item.content}}</text>
				<text>Drug：{{item.drug}}</text>
				<text>Date：{{item.date}}</text>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				uid:'',
				doctorlist:[]
				
			}
		},
		onLoad(option) {
			this.baseurl = getApp().globalData.text;
			this.uid = option.uid
			this.user = getApp().globalData.user;
			this.getdoctor()
		},
		methods: {
			getdoctor:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/orders/findAll',
					data:{
						uid:that.uid,
						state:'已诊断'
					},
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.doctorlist=res.data.data
						}
					}
				})
			},
		}
	}
</script>

<style>
	.item{
		width: calc(100% - 20px);
		height: auto;
		min-height: 50px;
		background-color: #ffffff;
		margin: 10px;
		padding: 10px;
		box-sizing: border-box;
		display: flex;
		flex-direction: column;
	}
	.item text{
		margin: 6px;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}

</style>
