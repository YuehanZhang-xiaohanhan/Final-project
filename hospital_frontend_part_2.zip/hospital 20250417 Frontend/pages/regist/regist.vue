<template>
	<view class="main">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="head">
					<image v-if="head === ''"  src="../../static/head.png" mode="widthFix" @click="choosepic"></image>
				<image v-if="head != ''" :src="`${baseurl}/public/${head}`" mode="widthFix" @click="choosepic"></image>
			</view>
			<view class="main-mian">
				<view >
					<text>UserName</text>
					<input type="text" placeholder="Please enter your account number" v-model="login.username" placeholder-class="placeholder">
				</view>
				<view >
					<text>NickName</text>
					<input type="text" placeholder="Please enter name" v-model="login.nickname" placeholder-class="placeholder">
				</view>
				<view >
					<text>Tel</text>
					<input type="text" placeholder="Please enter phone number" v-model="login.tel" placeholder-class="placeholder">
				</view>
				<view >
					<text>Pass</text>
					<input type="text" placeholder="Please enter your password" v-model="login.pass" placeholder-class="placeholder">
				</view>
				<view >
					<text>Age</text>
					<input type="number" placeholder="Please enter your age" v-model="login.age" placeholder-class="placeholder">
				</view>
				<view >
					<text>Sex</text>
					<radio-group style="margin-top: 10px;" @change="changesex">
						<radio value="男" checked>man</radio><radio value="女" style="margin-left: 10px;">woman</radio>
					</radio-group>
				</view>
			</view>
			<button class="btn" @click="regist">注册</button>
			<view style="height: 100px;"></view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				login:{
					username :'',
					pass:'',
					nickname:'',
					tel:'',
					age:'',
					sex:'男'
				},
				head:'',
				baseurl:''
				
				
			}
		},
		onLoad() {
			this.baseurl = getApp().globalData.text;
		},
		methods: {
			changesex(e){
				console.log('e',e);
				let that = this;
				that.sex = e.detail.value
			},
			regist(){
				let that = this;
				console.log(that.login.username == '')
				if(that.login.username == '' || that.login.pass == '' || that.login.nickname == '' || that.login.tel == '' ||that.head == '' ){
					uni.showToast({
					  title: '内容不能为空',
					  duration:2000,
					  icon:'none'
					})
				}
				else{
					uni.request({
						url:that.baseurl+'/user/add',
						data:{
							username:that.login.username,
							nickname:that.login.nickname,
							sex:that.login.sex,
							age:that.login.age,
							tel:that.login.tel,
							pass:that.login.pass,
							head:that.head,
						},
						success(res) {
							console.log(res)
							if(res.data.code == '500'){
								uni.showToast({
								  title: '账号已存在',
								  duration:2000,
								  icon:'none'
								})
							}
							else{
								uni.showToast({
								  title: '注册成功',
								  duration:2000,
								  icon:'success',
								  success() {
								  	  uni.navigateBack({ changed: true });
								  }
								})
								
							}
						}
					})
				}
			},
			
			choosepic(){
				let that = this;
				console.log('选择照片')
				uni.chooseImage({
					count:1,
					sizeType: ['original'],
					sourceType: ['album'],
					success(res) {
						console.log(res)
						const tempFilePaths = res.tempFilePaths;
						var tempFilePathss = res.tempFilePaths;
						console.log("图片"+tempFilePathss)
						that.head =tempFilePathss;
						uni.uploadFile({
												    url:that.baseurl+'/upload/imagewx',     // 后端api接口
												    filePath: tempFilePathss[0], // uni.chooseImage函数调用后获取的本地文件路劲
												    name:'file',     //后端通过'file'获取上传的文件对象
												    formData: {
														 'user': 'test'
													},
												    success:(res) => {
												        console.log(res)
														that.head = res.data
												    }
												});
					}
					
					
				})
				
			},
			
		}
	}
</script>

<style>
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		background-color: white;
		display: flex;
		flex-direction: column;
	}
	.head{
		width: 100%;
		height: 30%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.head image{
		width: 100px;
		height: 100px;
	}
	.main-mian{
		width: calc(100% - 80rpx);
		height: 60%;
		margin: 40rpx;
		display: flex;
		flex-direction: column;
	}
	.main-mian view{
		flex: 1;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.main-mian view input{
		margin-top: 5rpx;
		border-bottom: 1px solid #f2f2f2;
	}
	.btn{
		width: 360rpx;
		background-color: #3282b8;
		border-radius: 40rpx;
		color: #fff;
	}


</style>
