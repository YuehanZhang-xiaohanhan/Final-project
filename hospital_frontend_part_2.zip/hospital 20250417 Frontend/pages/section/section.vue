<template>
	<view class="main">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="hositem" >
				<image :src="`${baseurl}/public/${info.pic}`" ></image>
				<view class="con">
					<text>{{info.name}}</text>
				</view>
			</view>
			<view class="item"  v-for="(item, index) in sectionlist" :key="index"  @click="xq(item)">
				{{item.name}}
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				sectionlist:[]
			}
		},
		onLoad(option) {
			this.baseurl = getApp().globalData.text;
			let info= JSON.parse(option.item ? option.item : '[]');
			this.info = info
			console.log(option.title)
			this.user = getApp().globalData.user;
			this.getsection()
		},
		methods: {
			xq:function(e){
				let that = this
				uni.navigateTo({
					url:"/pages/doctor/doctor?item="+JSON.stringify(e)+'&hid='+that.info.id
				})
			},
			getsection:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/section/findAll',
					data:{
						tid:that.info.id
					},
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.sectionlist=res.data.data
						}
					}
				})
			},
		}
	}
</script>

<style>
	.con{
		width: calc(100% - 170px);
		margin-left: 10px;
	}
	image{
		height: 100%;
		width: 160px;
	}
	.hositem{
		width: calc(100% - 20px);
		height: 160px;
		margin: 10px;
		background-color: #fff;
		padding: 10px;
		box-sizing: border-box;
		display: flex;
	}
	.item{
		width: 94%;
		height: 50px;
		background-color: #fff;
		margin: 3%;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 10px;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		background-color: #f6f6f6;
	}

</style>
