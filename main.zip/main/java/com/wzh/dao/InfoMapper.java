package com.wzh.dao;

import com.wzh.model.Hospital;
import com.wzh.model.Info;

import java.util.List;

public interface InfoMapper {
    int deleteByPrimaryKey(String id);

    int insert(Info record);

    int insertSelective(Info record);

    Info selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Info record);

    int updateByPrimaryKey(Info record);
    List<Info> findAll(Info record);


}
