package com.wzh.dao;

import com.wzh.model.Consult;
import com.wzh.model.Doctor;

import java.util.List;

public interface ConsultMapper {
    int deleteByPrimaryKey(String id);

    int insert(Consult record);

    int insertSelective(Consult record);

    Consult selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Consult record);

    int updateByPrimaryKey(Consult record);

    List<Consult> findAll(Consult record);

}