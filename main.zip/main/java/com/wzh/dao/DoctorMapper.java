package com.wzh.dao;

import com.wzh.model.Doctor;
import com.wzh.model.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DoctorMapper {
    int deleteByPrimaryKey(String id);

    int insert(Doctor record);

    int insertSelective(Doctor record);

    Doctor selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Doctor record);

    int updateByPrimaryKey(Doctor record);

    List<Doctor> findAll(Doctor record);
    Doctor getByUsername(@Param("username") String username);

}