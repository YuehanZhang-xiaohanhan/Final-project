package com.wzh.dao;

import com.wzh.model.Chat;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ChatMapper {
    int deleteByPrimaryKey(String id);

    int insert(Chat record);

    int insertSelective(Chat record);

    Chat selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Chat record);

    int updateByPrimaryKey(Chat record);

    List<Chat> selectuserAll(@Param("uid")String uid, @Param("did") String did);

}