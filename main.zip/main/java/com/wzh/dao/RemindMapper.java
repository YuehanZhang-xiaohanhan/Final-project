package com.wzh.dao;

import com.wzh.model.Hospital;
import com.wzh.model.Remind;

import java.util.List;

public interface RemindMapper {
    int deleteByPrimaryKey(String id);

    int insert(Remind record);

    int insertSelective(Remind record);

    Remind selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Remind record);

    int updateByPrimaryKey(Remind record);

    List<Remind> findAll(Remind record);

}