package com.wzh.dao;

import com.wzh.model.Section;

import java.util.List;

public interface SectionMapper {
    int deleteByPrimaryKey(String id);

    int insert(Section record);

    int insertSelective(Section record);

    Section selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Section record);

    int updateByPrimaryKey(Section record);

    List<Section> findAll(Section record);

}