package com.wzh.service;

import com.wzh.dao.ConsultMapper;
import com.wzh.model.Consult;
import com.wzh.model.Doctor;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class ConsultService {
    @Resource
    ConsultMapper consultMapper;
    public int save(Consult consult) {
        return consultMapper.insertSelective(consult);
    }
    //    删除数据
    public int del(String id) {
        return consultMapper.deleteByPrimaryKey(id);
    }
    //    获取数据
    public Consult get(String id) {
        return consultMapper.selectByPrimaryKey(id);
    }
    //    更新数据
    public int  update( Consult u) {
        return consultMapper.updateByPrimaryKeySelective(u);
    }

    public List<Consult> findAll(Consult consult) {
        return consultMapper.findAll(consult);
    }
}
