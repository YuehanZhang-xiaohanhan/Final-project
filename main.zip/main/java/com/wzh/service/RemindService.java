package com.wzh.service;

import com.wzh.dao.RemindMapper;
import com.wzh.model.Remind;
import com.wzh.model.Section;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class RemindService {
    @Resource
    RemindMapper remindMapper;
    public int save(Remind remind) {
        return remindMapper.insertSelective(remind);
    }
    //    删除数据
    public int del(String id) {
        return remindMapper.deleteByPrimaryKey(id);
    }
    //    获取数据
    public Remind get(String id) {
        return remindMapper.selectByPrimaryKey(id);
    }
    //    更新数据
    public int  update( Remind u) {
        return remindMapper.updateByPrimaryKeySelective(u);
    }

    public List<Remind> findAll(Remind remind) {
        return remindMapper.findAll(remind);
    }
}
