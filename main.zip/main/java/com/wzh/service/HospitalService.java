package com.wzh.service;

import com.wzh.dao.HospitalMapper;
import com.wzh.model.Hospital;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class HospitalService {
    @Resource
    HospitalMapper hospitalMapper;
    public int save(Hospital hospital) {
        return hospitalMapper.insertSelective(hospital);
    }
    //    删除数据
    public int del(String id) {
        return hospitalMapper.deleteByPrimaryKey(id);
    }
    //    获取数据
    public Hospital get(String id) {
        return hospitalMapper.selectByPrimaryKey(id);
    }
    //    更新数据
    public int  update( Hospital u) {
        return hospitalMapper.updateByPrimaryKeySelective(u);
    }

    public List<Hospital> findAll(Hospital hospital) {
        return hospitalMapper.findAll(hospital);
    }
}
