package com.wzh.service;

import com.wzh.dao.SectionMapper;
import com.wzh.model.Hospital;
import com.wzh.model.Section;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class SectionService {
    @Resource
    SectionMapper  sectionMapper;
    public int save(Section section) {
        return sectionMapper.insertSelective(section);
    }
    //    删除数据
    public int del(String id) {
        return sectionMapper.deleteByPrimaryKey(id);
    }
    //    获取数据
    public Section get(String id) {
        return sectionMapper.selectByPrimaryKey(id);
    }
    //    更新数据
    public int  update( Section u) {
        return sectionMapper.updateByPrimaryKeySelective(u);
    }

    public List<Section> findAll(Section section) {
        return sectionMapper.findAll(section);
    }
}
