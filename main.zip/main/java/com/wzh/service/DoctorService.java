package com.wzh.service;

import com.wzh.dao.DoctorMapper;
import com.wzh.model.Doctor;
import com.wzh.model.Hospital;
import com.wzh.model.User;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class DoctorService {
    @Resource
    DoctorMapper doctorMapper;
    public int save(Doctor doctor) {
        return doctorMapper.insertSelective(doctor);
    }
    //    删除数据
    public int del(String id) {
        return doctorMapper.deleteByPrimaryKey(id);
    }
    //    获取数据
    public Doctor get(String id) {
        return doctorMapper.selectByPrimaryKey(id);
    }
    //    更新数据
    public int  update( Doctor u) {
        return doctorMapper.updateByPrimaryKeySelective(u);
    }

    public List<Doctor> findAll(Doctor doctor) {
        return doctorMapper.findAll(doctor);
    }

    public Doctor getByUsername(String username){
        return doctorMapper.getByUsername(username);
    }
}
