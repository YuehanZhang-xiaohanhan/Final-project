package com.wzh.service;

import com.wzh.dao.ChatMapper;
import com.wzh.model.Chat;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class ChatService {
    @Resource
    ChatMapper chatMapper;
    //    后台添加数据
    public int save(Chat chat) {
        return chatMapper.insertSelective(chat);
    }
    //    删除数据
    public int del(String id) {
        return chatMapper.deleteByPrimaryKey(id);
    }
    //    获取数据
    public Chat get(String id) {
        return chatMapper.selectByPrimaryKey(id);
    }
    //    更新数据
    public int  update( Chat u) {
        return chatMapper.updateByPrimaryKeySelective(u);
    }

    public List<Chat> selectuserAll(String uid, String did) {
        return chatMapper.selectuserAll(uid, did);
    }


}
