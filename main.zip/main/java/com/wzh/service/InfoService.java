package com.wzh.service;

import com.wzh.dao.InfoMapper;
import com.wzh.model.Info;
import com.wzh.model.Orders;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class InfoService {
    @Resource
    InfoMapper infoMapper;
    public int save(Info info) {
        return infoMapper.insertSelective(info);
    }
    //    删除数据
    public int del(String id) {
        return infoMapper.deleteByPrimaryKey(id);
    }
    //    获取数据
    public Info get(String id) {
        return infoMapper.selectByPrimaryKey(id);
    }
    //    更新数据
    public int  update( Info u) {
        return infoMapper.updateByPrimaryKeySelective(u);
    }

    public List<Info> findAll(Info i) {
        return infoMapper.findAll(i);
    }
}
