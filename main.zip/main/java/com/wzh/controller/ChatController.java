package com.wzh.controller;

import cn.hutool.core.util.IdUtil;
import com.wzh.model.Chat;
import com.wzh.model.Consult;
import com.wzh.model.User;
import com.wzh.service.ChatService;
import com.wzh.service.ConsultService;
import com.wzh.service.UserService;
import com.wzh.until.JsonObject;
import com.wzh.until.Time;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/chat")
public class ChatController {
    @Resource
    ChatService chatService;
    @Resource
    ConsultService consultService;
    @RequestMapping("/add")
    @ResponseBody
    public JsonObject save(Chat chat) {
        try {
            Consult consult = new Consult();
            consult.setTitle(chat.getContent());
            List<Consult>consultList = consultService.findAll(consult);
            if (consultList.size()>0){
                Chat chat1 = new Chat();
                chat1.setId(IdUtil.simpleUUID());
                chat1.setUid("1");
                chat1.setDid(chat.getUid());
                chat1.setContent(consultList.get(0).getContent());
                chat1.setTime(Time.getTime());
                chatService.save(chat1);
                chat.setId(IdUtil.simpleUUID());
                chat.setTime(Time.getTime());
                chatService.save(chat);
                System.out.println("添加数据");
                return new JsonObject("200","","");
            }
            else {
                chat.setId(IdUtil.simpleUUID());
                chat.setTime(Time.getTime());
                chatService.save(chat);
                System.out.println("添加数据");
                return new JsonObject("300","未查询到相关内容","");
            }
        }
        catch (Exception e){
            System.out.println(e.toString());
            return new JsonObject("500","失败","");
        }
    }
    @RequestMapping("/findAll")
    @ResponseBody
    public JsonObject findAll(@RequestParam("uid") String uid, @RequestParam("did") String did){
        List<Chat> list = chatService.selectuserAll(uid,did);
        System.out.println(list);
        try{
            return new JsonObject("200","", list);

        }
        catch (Exception e){
            System.out.println(e.toString());
            return new JsonObject("500","失败","");
        }
    }
    @Resource
    UserService userService;

}
