package com.wzh.controller;

import cn.hutool.json.JSONObject;
import com.wzh.until.DataJson;
import com.wzh.until.UploadUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;

@Controller
@RequestMapping("/upload")
public class CommonController {
    @Value("${server.port}")
    private String dkh;
    //    web上传图片
    @RequestMapping("/image")
    @ResponseBody
    public DataJson uploadImage(@RequestParam(value = "file") MultipartFile file) {
        String imagePath = UploadUtils.upload(file);//获得图片路径
        DataJson dataJson = new DataJson();
        if (imagePath != null) {
            dataJson.setCode(1);
            dataJson.setMsg("上传成功");
            HashMap<String, String> map = new HashMap<>();
            map.put("url", imagePath);
            dataJson.setData(map);
        } else {
            dataJson.setCode(0);
            dataJson.setMsg("上传失败");
        }
        return dataJson;
    }
    @RequestMapping("/imagewx")
    @ResponseBody
    public String uploadImagewx(@RequestParam(value = "file") MultipartFile file) {
        String imagePath = UploadUtils.upload(file);//获得图片路径
        if(imagePath!=null) {
            System.err.println("图片名"+imagePath);
            return imagePath;
        }else {
            return "";


        }
    }
    @RequestMapping("/ck_upload_img")
    @ResponseBody
    public JSONObject ck_upload_img(@RequestParam(value = "upload") MultipartFile file, HttpServletRequest request) {
        String imagePath = UploadUtils.upload(file);//获得图片路径
        JSONObject object = new JSONObject();
        try {
            object.put("uploaded", 1);
            object.put("fileName", imagePath);
            object.put("url", "http://localhost:"+dkh+"/public/"+imagePath);
            return object;
        } catch (Exception e) {
            object.put("uploaded", 0);
            object.put("error", new JSONObject().put("message", "图片上传失败！"));
            return object;
        }
    }


}
