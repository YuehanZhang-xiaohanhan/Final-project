package com.wzh.controller;

import cn.hutool.core.util.IdUtil;
import com.wzh.model.Info;
import com.wzh.model.Remind;
import com.wzh.model.Section;
import com.wzh.service.InfoService;
import com.wzh.service.RemindService;
import com.wzh.until.JsonObject;
import com.wzh.until.Time;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/remind")
public class RemindController {
    @Resource
    RemindService remindService;
    @RequestMapping("findAll")
    @ResponseBody
    public JsonObject findAll(Remind remind){
        try {
            List<Remind> list = remindService.findAll(remind);
            return new JsonObject("200","", list);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }
    }
    //    更新
    @RequestMapping("/update")
    @ResponseBody
    public JsonObject update(Remind remind) {
        try {
            remindService.update(remind);
            return new JsonObject("200", "", null);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
    @Resource
    InfoService infoService
            ;
    @RequestMapping("findAret")
    @ResponseBody
    public JsonObject findAret(Remind remind){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");

            List<Remind> list = remindService.findAll(remind);
            for (int i = 0; i < list.size(); i++) {
                Info info = new Info();
                info.setUid(remind.getUid());
                info.setTime(Time.getDate());
                info.setReminder(list.get(i).getReminder());
                List<Info>infoList = infoService.findAll(info);
                if (infoList.size()==0){
                    Date date = new Date();
                    String datestr = sdf2.format(date);
                    String dateString = datestr+" "+list.get(i).getReminder();
                    Date txdate = sdf.parse(dateString);
                    System.err.println("dateString="+dateString);
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(txdate);
                    calendar.add(Calendar.MINUTE, 1); // 在当前时间上增加1分钟
                    String newDateString = sdf.format(calendar.getTime());
                    Date newDate = sdf.parse(newDateString);
                    System.err.println("newDateString="+newDateString);
                    if (date.getTime()>txdate.getTime()&&date.getTime()<newDate.getTime()) {
                        Info info1 = new Info();
                        info1.setId(IdUtil.simpleUUID());
                        info1.setReminder(list.get(i).getReminder());
                        info1.setUid(remind.getUid());
                        info1.setTime(Time.getDate());
                        infoService.save(info1);
                        return new JsonObject("300","", "");

                    }

                }

            }

            return new JsonObject("200","", list);

        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }
    }
}
