package com.wzh.controller;

import cn.hutool.core.util.IdUtil;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wzh.model.*;
import com.wzh.service.DoctorService;
import com.wzh.service.HospitalService;
import com.wzh.service.OrdersService;
import com.wzh.service.SectionService;
import com.wzh.until.JsonObject;
import com.wzh.until.PageRet;
import com.wzh.until.Pass;
import com.wzh.until.Time;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/doctor")
public class DoctorController {
    @Resource
    DoctorService doctorService;
    @Value("${server.port}")
    private String dkh;
    @Resource
    SectionService sectionService;
    @Resource
    HospitalService hospitalService;

    @RequestMapping("/tolist")
    public String tolist(Model model) {
        model.addAttribute("dkh", dkh);
        Hospital hospital = new Hospital();
        List<Hospital> list = hospitalService.findAll(hospital);
        model.addAttribute("dlist",list);
        Section section = new Section();
        List<Section> sectionList = sectionService.findAll(section);
        model.addAttribute("slist",sectionList);
        return "Doctor/list";

    }
    //    分页查询
    @RequestMapping(value = "/pagegetall")
    @ResponseBody
    public PageRet list(@RequestParam(value = "page", defaultValue = "0") int page,
                        @RequestParam(value = "limit", defaultValue = "2") int limit,
                        Doctor doctor){
        Page<Doctor> pageInfo = PageHelper.startPage(page, limit, "");
        List<Doctor> list = doctorService.findAll(doctor);
        PageInfo<Doctor> all = new PageInfo<>(list);
        return new PageRet(0, "", all.getList(), (int) all.getTotal());
    }
    @RequestMapping("/toadd")
    public String toadd(Model model) {
        model.addAttribute("id", "");
        Hospital hospital = new Hospital();
        List<Hospital> list = hospitalService.findAll(hospital);
        model.addAttribute("dlist",list);
        Section section = new Section();
        List<Section> sectionList = sectionService.findAll(section);
        model.addAttribute("slist",sectionList);
        return "Doctor/add";
    }

    //新增数据
    @RequestMapping("/add")
    @ResponseBody
    public JsonObject save(@RequestParam("username") String username, Doctor doctor) {
        String str = Pass.opinions(doctor.getPass());
        if (str.equals("200")){
            Doctor u = doctorService.getByUsername(username);
            if (u ==null){
                String id = IdUtil.simpleUUID();
                doctor.setId(id);
                doctorService.save(doctor);
                System.out.println("添加数据");
                return new JsonObject("200", "", null);
            }else {
                return new JsonObject("500", "账号已经存在", null);
            }
        }
        else {
            return new JsonObject("300", "密码格式不对,请输入6到12位英文加数字", null);

        }

    }
    @RequestMapping("/del")
    @ResponseBody
    public JsonObject del(@RequestParam("id") String ids[]){
        try {
            for (String id : ids) {
                doctorService.del(id);
            }
            return new JsonObject("200", "", null);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
    @RequestMapping("/get")
    @ResponseBody
    public JsonObject get(@RequestParam("id") String id) {
        try {
            Doctor u = doctorService.get(id);
            return new JsonObject("200", "", u);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
    //    更新
    @RequestMapping("/update")
    @ResponseBody
    public JsonObject update(Doctor u) {
        try {
            doctorService.update(u);
            return new JsonObject("200", "", null);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }


    @RequestMapping("/toget")
    public String toget(@RequestParam("id") String id, Model model) {
        model.addAttribute("id", id);
        model.addAttribute("dkh", dkh);
        Hospital hospital = new Hospital();
        List<Hospital> list = hospitalService.findAll(hospital);
        model.addAttribute("dlist",list);
        Section section = new Section();
        List<Section> sectionList = sectionService.findAll(section);
        model.addAttribute("slist",sectionList);
        System.out.println("修改界面");
        return "Doctor/update";
    }
    @Resource
    OrdersService ordersService;
    @RequestMapping("findAll")
    @ResponseBody
    public JsonObject findAll(Doctor doctor,
                              @RequestParam("quantum")String quantum,
                              @RequestParam("date")String date){
        try {
            int cc = 6;
            List<Doctor> list = doctorService.findAll(doctor);
            List<Doctor> doctorList =new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                Doctor doctor1 = list.get(i);
                Orders orders = new Orders();
                orders.setQuantum(quantum);
                orders.setState("未诊断");
                orders.setDate(date);
                orders.setDid(list.get(i).getId());
                List<Orders>ordersList = ordersService.findAll(orders);
                if (ordersList.size()>=cc){
                    doctor1.setState("1");
                }
                else {
                    doctor1.setState("0");
                }
                doctorList.add(doctor1);

            }

            return new JsonObject("200","", doctorList);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }
    }
    @RequestMapping("/login")
    @ResponseBody
    public JsonObject login(@RequestParam("username") String username,
                            @RequestParam("pass") String pass
    ) {
        Doctor u = doctorService.getByUsername(username);
        if (u == null) {
            System.out.println("账号不存在");
            return new JsonObject("500", "账号不存在", "");
        } else if (u.getPass().equals(pass) && u.getUsername().equals(username)) {
            return new JsonObject("200", "", u);
        } else {
            System.out.println("密码错误");
            return new JsonObject("300", "密码错误", "");
        }
    }
    @RequestMapping("/updateuser")
    @ResponseBody
    public JsonObject updateuser(Doctor u) {
        try {
            doctorService.update(u);
            Doctor doctor = doctorService.get(u.getId());
            return new JsonObject("200", "", doctor);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
    @RequestMapping("/updatepass")
    @ResponseBody
    public JsonObject updatepass(Doctor u) {
        try {
            String str = Pass.opinions(u.getPass());
            if (str.equals("200")){
                doctorService.update(u);
                return new JsonObject("200", "", null);
            }
            else {
                return new JsonObject("300", "密码格式不对,请输入6到12位英文加数字", null);
            }
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
}
