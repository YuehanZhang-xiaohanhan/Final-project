package com.wzh.controller;

import cn.hutool.core.util.IdUtil;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wzh.model.Hospital;
import com.wzh.model.Orders;
import com.wzh.model.Remind;
import com.wzh.service.HospitalService;
import com.wzh.service.OrdersService;
import com.wzh.service.RemindService;
import com.wzh.service.UserService;
import com.wzh.until.JsonObject;
import com.wzh.until.PageRet;
import com.wzh.until.Time;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/orders")
public class OrdersController {
    @Resource
    OrdersService ordersService;
    @Value("${server.port}")
    private String dkh;

    @RequestMapping("/tolist")
    public String tolist(Model model) {
        model.addAttribute("dkh", dkh);
        return "orders/list";

    }
    //    分页查询
    @RequestMapping(value = "/pagegetall")
    @ResponseBody
    public PageRet list(@RequestParam(value = "page", defaultValue = "0") int page,
                        @RequestParam(value = "limit", defaultValue = "2") int limit,
                        Orders orders){
        Page<Orders> pageInfo = PageHelper.startPage(page, limit, "time desc");
        List<Orders> list = ordersService.findAll(orders);
        PageInfo<Orders> all = new PageInfo<>(list);
        return new PageRet(0, "", all.getList(), (int) all.getTotal());
    }
    @RequestMapping("/toadd")
    public String toadd(Model model) {
        model.addAttribute("id", "");
        return "Orders/add";
    }

    //新增数据
    @RequestMapping("/add")
    @ResponseBody
    public JsonObject save(Orders orders) {
        try {
            orders.setState("未诊断");
            orders.setId(IdUtil.simpleUUID());
            orders.setTime(Time.getTime());
            ordersService.save(orders);
            System.out.println("添加数据");
            return new JsonObject("200", "", null);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
    @RequestMapping("/del")
    @ResponseBody
    public JsonObject del(@RequestParam("id") String ids[]){
        try {
            for (String id : ids) {
                ordersService.del(id);
            }
            return new JsonObject("200", "", null);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
    @RequestMapping("/get")
    @ResponseBody
    public JsonObject get(@RequestParam("id") String id) {
        try {
            Orders u = ordersService.get(id);
            return new JsonObject("200", "", u);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
    //    更新
    @RequestMapping("/update")
    @ResponseBody
    public JsonObject update(Orders u) {
        try {
            ordersService.update(u);
            return new JsonObject("200", "", null);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }
    @Resource
    UserService userService;
    @Resource
    RemindService remindService;
    @RequestMapping("/zdupdate")
    @ResponseBody
    public JsonObject zdupdate(Orders u) {
        try {
            Orders  orders = ordersService.get(u.getUid());
            Remind remind = new Remind();
            remind.setUid(orders.getUid());
            List<Remind>list = remindService.findAll(remind);
            if (list.size()==0){
                Remind remind1 = new Remind();
                remind1.setId(IdUtil.simpleUUID());
                remind1.setUid(orders.getUid());
                remind1.setStatus("0");
                remind1.setReminder("12:00:00");
                remind1.setTime(Time.getTime());
                remindService.save(remind1);
                Remind remind12 = new Remind();
                remind12.setId(IdUtil.simpleUUID());
                remind12.setUid(orders.getUid());
                remind12.setStatus("0");
                remind12.setReminder("18:00:00");
                remind12.setTime(Time.getTime());
                remindService.save(remind12);

            }
            ordersService.update(u);
            return new JsonObject("200", "", null);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }

    }

    @RequestMapping("/toget")
    public String toget(@RequestParam("id") String id, Model model) {
        model.addAttribute("id", id);
        model.addAttribute("dkh", dkh);
        System.out.println("修改界面");
        return "Orders/add";
    }

    @RequestMapping("findAll")
    @ResponseBody
    public JsonObject findAll(Orders orders){
        try {
            List<Orders> list = ordersService.findAll(orders);
            return new JsonObject("200","", list);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }
    }
    @RequestMapping("findsize")
    @ResponseBody
    public JsonObject findsize(Orders orders){
        try {
            List<Orders> list = ordersService.findAll(orders);
            return new JsonObject("200","", list.size());
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }
    }
    @RequestMapping("findDATE")
    @ResponseBody
    public JsonObject findDATE(Orders orders){
        try {
            List<Orders> list = ordersService.findDATE(orders);
            return new JsonObject("200","", list);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }
    }
    @RequestMapping("findDate")
    @ResponseBody
    public JsonObject findDate(){
        try {
            List<DateStr>dateStrList =  new ArrayList<>();
            Date now = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");//定义日期格式
            for (int i = 0; i < 5; i++) {
                Date date = new Date(now.getTime() + i * 24 * 3600 * 1000);
                String dateString = dateFormat.format(date);//将时间格式化为字符串
                int month1 = date.getMonth() + 1;
                int day = date.getDate();
                Date dt2 = new Date(now.getTime() + i * 24 * 3600 * 1000);
                String[] weekDay = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
                DateStr d = new DateStr();
                d.setDate(dateString);
                d.setWeek(weekDay[dt2.getDay()]);
                d.setRiqi(month1+"."+day);
                dateStrList.add(d);
            }
            return new JsonObject("200","", dateStrList);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }
    }
    @RequestMapping("findquart")
    @ResponseBody
    public JsonObject findquart(@RequestParam("date") String date){
        try {
            System.err.println("date="+date);
            List<String>quantumList = new ArrayList<>();
            quantumList.add("08:00 - 09:00");
            quantumList.add("09:00 - 10:00");
            quantumList.add("10:00 - 11:00");
            quantumList.add("11:00 - 12:00");
            quantumList.add("12:00 - 13:00");
            quantumList.add("13:00 - 14:00");
            quantumList.add("14:00 - 15:00");
            quantumList.add("15:00 - 16:00");
            quantumList.add("16:00 - 17:00");
            List<QuartStr>quartStrs = new ArrayList<>();
            Date da = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String dateString = dateFormat.format(da);
            System.err.println("dateString="+dateString);

            for (int i = 0; i < quantumList.size(); i++) {
                Calendar calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                if (dateString.equals(date)){
                    if (hour<Integer.parseInt(quantumList.get(i).substring(0,2))){
                        QuartStr quartStr = new QuartStr();
                        quartStr.setName(quantumList.get(i));
                        quartStr.setState("1");
                        quartStrs.add(quartStr);
                    }
//                    else {
//                        QuartStr quartStr = new QuartStr();
//                        quartStr.setName(quantumList.get(i));
//                        quartStr.setState("0");
//                        quartStrs.add(quartStr);
//                    }
                }
                else {
                    QuartStr quartStr = new QuartStr();
                    quartStr.setName(quantumList.get(i));
                    quartStr.setState("1");
                    quartStrs.add(quartStr);
                }

            }

            return new JsonObject("200","", quartStrs);
        }
        catch (Exception e){
            return new JsonObject("500","失败","");
        }
    }
    public static void main(String[] args) {
        List<String>quantumList = new ArrayList<>();
        quantumList.add("08:00 - 09:00");
        quantumList.add("09:00 - 10:00");
        quantumList.add("10:00 - 11:00");
        quantumList.add("11:00 - 12:00");
        quantumList.add("12:00 - 13:00");
        quantumList.add("13:00 - 14:00");
        quantumList.add("14:00 - 15:00");
        quantumList.add("15:00 - 16:00");
        quantumList.add("16:00 - 17:00");
        List<QuartStr>quartStrs = new ArrayList<>();

        for (int i = 0; i < quantumList.size(); i++) {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            if (hour<Integer.parseInt(quantumList.get(i).substring(0,2))){
                QuartStr quartStr = new QuartStr();
                quartStr.setName(quantumList.get(i));
                quartStr.setState("1");
                quartStrs.add(quartStr);
            }
            else {
                QuartStr quartStr = new QuartStr();
                quartStr.setName(quantumList.get(i));
                quartStr.setState("0");
                quartStrs.add(quartStr);
            }
        }
        System.err.println("quartStrs="+quartStrs);
    }
    public static class QuartStr{
        private String name;
        private String state;

        public String getName() {
            return name;
        }

        @Override
        public String toString() {
            return "QuartStr{" +
                    "name='" + name + '\'' +
                    ", state='" + state + '\'' +
                    '}';
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }
    }
    public static class DateStr{
        private String date;
        private String week;
        private String riqi;

        public String getDate() {
            return date;
        }

        @Override
        public String toString() {
            return "DateStr{" +
                    "date='" + date + '\'' +
                    ", week='" + week + '\'' +
                    ", riqi='" + riqi + '\'' +
                    '}';
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getWeek() {
            return week;
        }

        public void setWeek(String week) {
            this.week = week;
        }

        public String getRiqi() {
            return riqi;
        }

        public void setRiqi(String riqi) {
            this.riqi = riqi;
        }
    }



}
