<template>
	<view class="main" style="background-color: #f6f6f6;padding: 10px;box-sizing: border-box;">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="doitem" v-for="(item, index) in doctorlist" :key="index">
				<view class="dohead" @click="xq(item)">
					<image :src="`${baseurl}/public/${item.uhead}`" ></image>
				</view>
				<view class="docon" @click="xq(item)">
					<text style="font-size: 14px;font-weight: 600;">{{item.nickname}}</text>
					<view style="margin-top: 10px;">
						<text style="font-size: 12px;">Sex：{{item.sex}}  Age：{{item.age}}</text>
					</view>
					<view style="margin-top: 10px;">
						<text style="font-size: 12px;">{{item.date}} {{item.quantum}}</text>
					</view>
					<text style="font-size: 12px;margin-top: 10px;color: #F56C6C;">{{item.state}}</text>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				doctorlist:[]
			}
		},
		onLoad(option) {
			
			
		},
		onShow() {
			this.baseurl = getApp().globalData.text;
			this.user = getApp().globalData.user;
			this.getdoctor()
		},
		methods: {
			xq:function(e){
				uni.navigateTo({
					url:"/pages/patientdetails/patientdetails?item="+JSON.stringify(e)
				})
			},
			getdoctor:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/orders/findDATE',
					data:{
						did:that.user.id,
					},
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.doctorlist=res.data.data
						}
					}
				})
			},
		}
	}
</script>

<style>
page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.ym{
		width: 60px;
		height: 30px;
		background-color: #f6f6f6;
		color: #000;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		border-radius: 10px;
	}
	.yy{
		width: 60px;
		height: 30px;
		background-color: #1296db;
		color: #fff;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		border-radius: 10px;
	}
	.dobtn{
		height: 100%;
		display: flex;
		align-items: flex-end;
		flex-direction: column;
		justify-content: flex-end;
	}
	
	.docon{
		flex: 1;
		display: flex;
		flex-direction: column;
	}
	.dohead{
		width: 80px;
		
	}
	.dohead image{
		width: 70px;
		height: 70px;
		border-radius: 50%;
	}
	.doitem{
		width: calc(100% - 20px);
		height: 140px;
		background-color: #fff;
		margin: 10px;
		display: flex;
		padding: 10px;
		box-sizing: border-box;
	}
</style>
