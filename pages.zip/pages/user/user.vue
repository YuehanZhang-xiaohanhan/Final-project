<template>
	<view class="main">
		<view class="head" style="display: flex;flex-direction: column;">
			<image :src="`${baseurl}/public/${user.head}`" ></image>
		</view>
		<view class="content">
			
			<view class="content_item" @click="gotouser">
				<view class="content_t"></view>
				<text class="text">Personal Information</text>
				<image src="../../static/ysj.png" mode=""></image>
			</view>
			<view class="content_item" @click="gotopass">
				<view class="content_t"></view>
				<text class="text">Change Password</text>
				<image src="../../static/ysj.png" mode=""></image>
			</view>
			<view class="content_item" @click="exituser">
				<view class="content_t"></view>
				<text class="text">Exit account</text>
				<image src="../../static/ysj.png" mode=""></image>
			</view>
		</view>
	</view>
</template>

<script>
	import app from '@/App.vue';
	export default {
		data() {
			return {
				baseurl:'',
				user:{},
				show: false,
			}
		},
		onShow() {
			this.baseurl = getApp().globalData.text;
			this.user = getApp().globalData.user;
		},
		methods: {
			
			
			exituser(){
				uni.showModal({
				    title: 'hint',
				    content: 'Confirm exit code ？',
					confirmText:"affirm",
					cancelText:"cancel",
				    success: function (res) {
				        if (res.confirm) {
				            uni.reLaunch({
				            	url:"/pages/login/login"
				            })
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
			},
			gotouser(){
				uni.navigateTo({
					url:'/pages/userupdate/userupdate'
				})
			},
			gotopass(){
				uni.navigateTo({
					url:'/pages/updatepass/updatepass'
				})
			},
			
		}
	}
</script>

<style>
page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.head{
		width: 100%;
		height: 30%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.head image{
		width: 200rpx;
		height: 200rpx;
		border-radius: 50%;
	}
	.content{
		margin: 20rpx;
	}
	.content_item{
		height: 80rpx;
		display: flex;
		align-items: center;
		border-bottom: 1rpx solid #ccc;
	}
	.content_t{
		width: 20rpx;
		height: 20rpx;
		background-color: #3282b8;
		border-radius: 10rpx;
		margin-right: 20rpx;
	}
	.content_item image{
		width: 30rpx;
		height: 30rpx;
	}
	.text{
		flex: 8;
	}
</style>
