<template>
	<view class="main" style="padding: 10px;box-sizing: border-box;background-color: #f6f6f6;">
		<view class="head">
			<image :src="`${baseurl}/public/${info.head}`" ></image>
			<view class="con">
				<text style="font-size: 16px;font-weight: 600;">{{info.name}}</text>
				<text style="font-size: 14px;margin-top: 10px;">{{info.post}}</text>
			</view>
		</view>
		<view class="conn">
			<text style="font-size: 14px;margin-top: 10px;">Specialty:{{info.specialty}}</text>
		</view>
		<view class="conn">
			<text style="font-size: 14px;margin-top: 10px;">Focus Areas:{{info.focusareas}}</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				info:{}
			}
		},
		onLoad(option) {
			this.baseurl = getApp().globalData.text;
			let info= JSON.parse(option.item ? option.item : '[]');
			this.info = info
			this.user = getApp().globalData.user;
			uni.setNavigationBarTitle({
				title: this.info.name
			});
		},
		methods: {
			
		}
	}
</script>

<style>
	.con{
		width: calc(100% - 110px);
		margin-left: 10px;
		display: flex;
		flex-direction: column;
	}
	.head image{
		width: 100px;
		height: 100px;
		border-radius: 50%;
	}
	.conn text{
		line-height: 28px;
	}
	.conn{
		width: 94%;
		height: auto;
		background-color: #fff;
		margin-left: 3%;
		padding: 10px;
		box-sizing: border-box;
		border-radius: 10px;
		display: flex;
		margin-top: 20px;
	}
	.head{
		width: 94%;
		height: 120px;
		background-color: #fff;
		margin-left: 3%;
		padding: 10px;
		box-sizing: border-box;
		border-radius: 10px;
		display: flex;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}

</style>
