<template>
	<view class="main" style="background-color: #f5f5f5;">
		<scroll-view scroll-y="true" style="height: 85%;">
			<block v-for="(item, index) in infoList" :key="index">
				<view class="wdmsg" v-if="item.uid === user.id">
					<text>{{item.content}}</text>
					
				</view>
				<view class="ddmsg" v-else>
					<text>{{item.content}}</text>
					
				</view>
			</block>
			
		</scroll-view>
		<view class="btoview" style="">
			<input placeholder="Please enter content" v-model="content"/>
			<view @click="fs">send</view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				content:'',
				infoList:[],
				user:{}
				
			}
		},
		
		onShow() {
			this.baseurl = getApp().globalData.text;
			this.user = getApp().globalData.user;
			this.getinfo()
		},
		methods: {
			getinfo:function(){
				let that = this
				uni.request({
					url:that.baseurl+'/chat/findAll',
					data:{
						uid:that.user.id,
						did:'1',
					},
					success(res) {
						if(res.data.code == '200'){
							that.infoList = res.data.data
						}
					}
				})
			},
			fs:function(){
				let that = this
				if(that.content === ''){
					uni.showToast({
						title:'请输入内容',
						icon:'none'
					})
				}
				else{
					uni.request({
						url:that.baseurl+'/chat/add',
						data:{
							uid:that.user.id,
							did:'1',
							content:that.content,
						},
						success(res) {
							if(res.data.code == '200'){
								 wx.showToast({
								                  title: '发送中',
								                  duration: 3000,
								                  icon: "loading",
								                  success: function () {
								                    setTimeout(function(){
								                      wx.showToast({
								                        title: '发送成功',
								                        success:function(){
								                          setTimeout(function () {
															  that.content = ''
								                           that.getinfo()
								                          },1000)
								                        }
								                      })
								                    },1000)
								                  }
								                })
							}
							else{
								uni.showToast({
									title:res.data.msg,
									icon:'none'
								})
							}
						}
					})
				}
			}
		}
	}
</script>

<style>
	.ddmsg{
		width: 96%;
		height: auto;
		min-height: 40px;
		display: flex;
		align-items: center;
		margin-left: 2%;
	}
	.ddmsg text{
		background-color: #fff;
		padding: 4px 6px;
		border-radius: 10px;
	}
	.wdmsg{
		width: 96%;
		height: auto;
		min-height: 40px;
		display: flex;
		align-items: center;
		justify-content: flex-end;
	}
	.wdmsg text{
		background-color: #95ec69;
		padding: 4px 6px;
		border-radius: 10px;
	}
	.btoview{
		height: 15%;
		padding-left: 20px;
		padding-right: 20px;
		box-sizing: border-box;
		width: 100%;
		display: flex;
		align-items: center;
	}
	.btoview view{
		width: 60px;
		height: 45px;
		background-color: #409EFF;
		margin-left: 10px;
		color: #fff;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 10px;
	}
	.btoview input{
		flex: 1;
		height: 45px;
		border: 1px solid #409EFF;
		background-color: #fff;
		padding-left: 10px;
		box-sizing: border-box;
		border-radius: 10px;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}

</style>
