<template>
	<view class="main" style="background-color: #f6f6f6;">
		<scroll-view scroll-y="true" style="height: 100%;">
			<view class="io" @click="patient">
				<image src="/static/bh.png"></image>
				<text>Patient of the day</text>
			</view>
			<view class="io" @click="tappatient">
				<image src="/static/bh.png"></image>
				<text>All patients</text>
			</view>
			<view class="io" @click="gotouser">
				<image src="/static/user.png"></image>
				<text>Personal Information</text>
			</view>
			<view class="io" @click="gotopass">
				<image src="/static/pass.png"></image>
				<text>Change Password</text>
			</view>
			<view class="io" @click="gotoexit">
				<image src="/static/exit2.png"></image>
				<text>Exit account</text>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			gotouser(){
				uni.navigateTo({
					url:'/pages/doctorupdate/doctorupdate'
				})
			},
			gotopass(){
				uni.navigateTo({
					url:'/pages/doctorpass/doctorpass'
				})
			},
			gotoexit(){
				uni.showModal({
				    title: '提示',
				    content: '确认退出嘛 ？',
				    success: function (res) {
				        if (res.confirm) {
				            uni.reLaunch({
				            	url:"/pages/login/login"
				            })
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
			},
			patient(){
				uni.navigateTo({
					url:'/pages/patient/patient'
				})
			},
			tappatient(){
				uni.navigateTo({
					url:'/pages/allpatient/allpatient'
				})
			}
			
		}
	}
</script>

<style>
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.io{
		width: 90%;
		height: 50px;
		background-color: #fff;
		margin: 5%;
		border-radius: 10px;
		display: flex;
		align-items: center;
		padding-left: 20px;
		box-sizing: border-box;
	}
	.io image{
		width: 30px;
		height: 30px;
	}
	.io text{
		margin-left: 10px;
	}

</style>
