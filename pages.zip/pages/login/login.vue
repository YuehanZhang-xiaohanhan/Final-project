<template>
	<view class="main-mian">
		<view class="main" style="display: flex;flex-direction: column;align-items: center;justify-content: center;">
			<image src="../../static/cwd.png" mode="widthFix"></image>
			<text class="title">Hospital</text>
		</view>
		<view class="mian-login">
			<view class="login">
				<view class="login-title">
					<text>Login</text>
				</view>
				<view class="login-username">
					<text>UserName</text>
					<input type="text" v-model="login.username"  placeholder="Please enter your account number" placeholder-class="placeholder" >
				</view>
				<view class="login-pass">
					<text>Pass</text>
					<input type="password" v-model="login.pass" placeholder=" Please enter your password" placeholder-class="placeholder">
				</view>
				<view class="login-pass">
					<text>Role</text>
					<radio-group style="margin-top: 10px;" @change="changerole">
						<radio value="用户" checked>User</radio><radio value="医生" style="margin-left: 10px;">Doctor</radio>
					</radio-group>
				</view>
			</view>
			<button class="btn" @click="dl">Login</button>
			<view class="regist" @click="regist">
				Register an account
			</view>
		</view>
	</view>
</template>

<script>
	import app from '@/App.vue';
	export default {
		data() {
			return {
				login:{
					username :'',
					pass:'',
					role:'用户'
				},
				baseurl:'',
				
			}
		},
		onLoad() {
			this.baseurl = getApp().globalData.text
		},
		
		methods: {
			changerole(e){
				let that = this
				console.log(e.detail.value);
				that.login.role = e.detail.value
			},
			dl(){
				let that = this;
				let role = that.login.role;
				let username = that.login.username;
				let pass = that.login.pass;
				
				if(username === ''|| pass === ''){
					console.log('请填写完整信息');
					uni.showToast({
						title:'请填写完整信息',
						icon: 'none',
							duration: 2000
					})
				}
				else{
					if(role === '用户'){
						uni.request({
							url:that.baseurl+'/user/login',
							data:{
								username:that.login.username,
								pass:that.login.pass
							},success: (res) => {
								if(res.data.code === '200'){
									getApp().globalData.user = res.data.data
									uni.switchTab({
									    url: '/pages/main/main'
									});
									
								}
								else{
									uni.showToast({
									  title: res.data.msg,
									  duration:2000,
									  icon:'none'
									})
								}
								console.log(res.data);
								
							}
						})
						}
						else{
							uni.request({
								url:that.baseurl+'/doctor/login',
								data:{
									username:that.login.username,
									pass:that.login.pass
								},success: (res) => {
									if(res.data.code === '200'){
										getApp().globalData.user = res.data.data
										uni.reLaunch({
											url:'/pages/Doctormain/Doctormain'
										})
										
									}
									else{
										uni.showToast({
										  title: res.data.msg,
										  duration:2000,
										  icon:'none'
										})
									}
									console.log(res.data);
									
								}
							})
						}
					}
					
					
				
			},
			regist(){
				uni.navigateTo({
					url:"/pages/regist/regist"
				})
				
			},
			
			
			
			
		}
	}
</script>

<style>
	.title{
		margin-top: 10px;
		font-size: 22px;
		font-weight: 700;
		letter-spacing: 2px;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main-mian{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 50%;
		background-color: #fff;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		box-sizing: border-box;
		}
	.main image{
		width: 30%;
		margin-top: -160rpx;
	}
	.mian-login{
		width: calc(100% - 120rpx);
		height: 500rpx;
		margin: 20rpx;
		background-color: #fff;
		border-radius: 20rpx;
		margin-top: -200rpx;
		padding: 40rpx;
		 box-shadow: 0 2px 4px rgba(0, 0, 0, .20);
		
	}
	.login{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.login-title{
		flex: 1;
		display: flex;
		justify-content: center;
	}
	.login-title text{
		font-weight: 700;
		font-size: 28rpx;
	}
	.login-username{
		flex: 1.5;
	}
	.login-pass{
		flex: 1.5;
	}
	.login-white{
		flex: 1;
		background-color: #3282b8;
	}
	.mian-login view view input{
		margin-top: 10rpx;
		padding-bottom: 10rpx;
		border-bottom: 1px solid #f2f2f2;
	}
	.placeholder{
		color:#d5d5d6;font-size:26rpx
	}
	.btn{
		width: 360rpx;
		background-color: #3282b8;
		border-radius: 40rpx;
		color: #fff;
	}
	.regist{
		width: 100%;
		color: #3282b8;
		font-size: 20rpx;
		display: flex;
		justify-content: center;
		margin-top: 20rpx;
	}

</style>
