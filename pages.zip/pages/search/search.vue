<template>
	<view class="main">
		<view class="serch">
			<input class="serchinput" type="text" placeholder="Please enter content" v-model="content">
			<view @click="searchclick">search</view>
		</view>
		<scroll-view scroll-y="true" style="height: 90%;">
			<view class="item" v-for="(item, index) in hoslist" :key="index"  @click="xq(item)">
				<image :src="`${baseurl}/public/${item.pic}`" ></image>
				<view class="con">
					<text>{{item.name}}</text>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				content:'',
				hoslist:[]
			}
		},
		onShow() {
			this.baseurl = getApp().globalData.text;
		},
		methods: {
			xq:function(e){
				uni.navigateTo({
					url:"/pages/section/section?item="+JSON.stringify(e)
				})
			},
			searchclick:function(){
				let that = this
				if(that.content === ''){
					uni.showToast({
						title:'Please enter content',
						icon:'none'
					})
					
				}
				else{
					let that = this;
					uni.request({
						url:that.baseurl+'/hospital/findAll',
						data:{
							name:that.content
						},
						success(res) {
							console.log(res)
							if(res.data.code =='200'){
								that.hoslist=res.data.data
							}
						}
					})
				}
			},
			
		}
	}
</script>

<style>
	.con{
		width: calc(100% - 170px);
		margin-left: 10px;
	}
	.item image{
		height: 100%;
		width: 160px;
	}
	.item{
		width: calc(100% - 20px);
		height: 160px;
		margin: 10px;
		background-color: #fff;
		padding: 10px;
		box-sizing: border-box;
		display: flex;
	}
	.serchinput{
		flex: 1;
		border: 1px solid #3282b8;
		height: 40px;
		border-radius: 10px;
		padding-left: 10px;
		box-sizing: border-box;
	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		background-color: #f6f6f6;
	}
	.serch{
		width: 100%;
		height: 50px;
		padding-left: 10px;
		padding-right: 10px;
		box-sizing: border-box;
		display: flex;
		align-items: center;
		
	}
	.serch view{
		width: 70px;
		background-color: #3282b8;
		height: 40px;
		margin-left: 10px;
		border-radius: 10px;
		color: #fff;
		display: flex;
		align-items: center;
		justify-content: center;
	}

</style>
