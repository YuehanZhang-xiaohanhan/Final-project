<template>
	<view class="main" style="padding: 10px;box-sizing: border-box;background-color: #f6f6f6;">
		<scroll-view scroll-x :show-scrollbar="false" style="white-space: nowrap;" >
			<view class="dateitem" v-for="(item, index) in dateList" :key="index">
				<view class="date" :class="[item.date === this.xzdate ? 'mritem' : 'ptitem']" @click="dateqh(item.date)">
					<text style="font-size: 12px;">{{item.week}}</text>
					<text style="margin-top: 5px;font-size: 14px;">{{item.riqi}}</text>
				</view>
			</view>
		</scroll-view>
		<scroll-view scroll-x :show-scrollbar="false" style="white-space: nowrap;margin-top: 20px;" >
			<view class="quartitem" v-for="(item, index) in quartList" :key="index">
				<view class="quart0" v-if="item.state === '0'" >
					<text>{{item.name}}</text>
				</view>
				<view class="quart" v-else :class="[item.name === this.xzquart ? 'mrquitem' : 'ptquitem']" @click="datequart(item.name)">
					<text>{{item.name}}</text>
				</view>
			</view>
		</scroll-view>
		<scroll-view scroll-y="true" style="height: calc(100% - 200px);margin-top: 20px;">
			<view class="doitem" v-for="(item, index) in doctorlist" :key="index">
				<view class="dohead" @click="xq(item)">
					<image :src="`${baseurl}/public/${item.head}`" ></image>
				</view>
				<view class="docon" @click="xq(item)">
					<text style="font-size: 14px;font-weight: 600;">{{item.name}}</text>
					<text style="font-size: 12px;margin-top: 10px;">{{item.post}}</text>
					<text style="font-size: 12px;margin-top: 10px;">{{item.specialty}}</text>
				</view>
				<view style="margin-left: 10px;" class="dobtn">
					<view class="ym" v-if="item.state === '1'">Meet</view>
					<view @click="add(item)" v-else class="yy">make</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				xzdate:'',
				xzquart:'',
				doctorlist:[],
				hid:'',
				dateList:[],
				quartList:[]
			}
		},
		onLoad(option) {
			this.baseurl = getApp().globalData.text;
			let info= JSON.parse(option.item ? option.item : '[]');
			this.info = info
			this.user = getApp().globalData.user;
			this.hid = option.hid
			uni.setNavigationBarTitle({
				title: this.info.name
			});
		},
		onShow() {
			this.getdate()
		},
		methods: {
			xq:function(e){
				uni.navigateTo({
					url:"/pages/doctorxq/doctorxq?item="+JSON.stringify(e)
				})
			},
			add:function(e){
				let that = this
				uni.showModal({
				    title: 'hint',
				    content: 'Confirm the appointment. Make a date：'+that.xzdate+',time quantum：'+that.xzquart+',doctor：'+e.name,
				    success: function (res) {
				        if (res.confirm) {
				            uni.request({
				            	url:that.baseurl+'/orders/add',
								data:{
									uid:that.user.id,
									hid:that.hid,
									sid:that.info.id,
									quantum:that.xzquart,
									date:that.xzdate,
									hname:e.name,
									sname:that.info.name,
									did:e.id
								},
				            	success(res) {
				            		console.log(res)
				            		if(res.data.code =='200'){
				            			uni.showToast({
				            				title:'预约成功',
											icon:'none',
											success() {
												uni.switchTab({
													url:'/pages/main/main'
												})
											}
				            			})
				            		}
				            	}
				            })
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
			},
			datequart:function(e){
				let that = this;
				this.xzquart = e
				that.getdoctor()
			},
			dateqh:function(e){
				let that = this;
				that.xzdate = e
				that.getquart()
			},
			getdate:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/orders/findDate',
					
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.dateList=res.data.data
							that.xzdate = res.data.data[0].date
							console.log('that.xzdate',that.xzdate);
							that.getquart()
						}
					}
				})
			},
			getquart:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/orders/findquart',
					data:{
						date:that.xzdate
					},
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.quartList=res.data.data
							that.xzquart = res.data.data[0].name
							that.getdoctor()
						}
					}
				})
			},
			getdoctor:function(){
				let that = this;
				uni.request({
					url:that.baseurl+'/doctor/findAll',
					data:{
						sid:that.info.id,
						hid:that.hid,
						quantum:that.xzquart,
						date:that.xzdate
					},
					success(res) {
						console.log(res)
						if(res.data.code =='200'){
							that.doctorlist=res.data.data
						}
					}
				})
			},
		}
	}
</script>

<style>
	.ym{
		width: 60px;
		height: 30px;
		background-color: #f6f6f6;
		color: #000;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		border-radius: 10px;
	}
	.yy{
		width: 60px;
		height: 30px;
		background-color: #1296db;
		color: #fff;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		border-radius: 10px;
	}
	.dobtn{
		height: 100%;
		display: flex;
		align-items: flex-end;
		flex-direction: column;
		justify-content: flex-end;
	}
	
	.docon{
		flex: 1;
		display: flex;
		flex-direction: column;
	}
	.dohead{
		width: 80px;
		
	}
	.dohead image{
		width: 70px;
		height: 70px;
		border-radius: 50%;
	}
	.doitem{
		width: calc(100% - 20px);
		height: 140px;
		background-color: #fff;
		margin: 10px;
		display: flex;
		padding: 10px;
		box-sizing: border-box;
	}
	.quartitem{
		display: inline-block;
		 width: 140px;
		 height: 40px;
		 margin-right: 10px; 
		 border-radius: 50%;
	
	}
	.ptquitem{
		background-color: #fff;
		border-radius: 10px;
	}
	.mrquitem{
		background-color: #1296db;
		color: #fff;
		border-radius: 10px;
	}
	.ptitem{
		background-color: #fff;
		border-radius: 50%;
	}
	.mritem{
		background-color: #1296db;
		color: #fff;
		border-radius: 50%;
	}
	.quart0{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: #F56C6C;
		border-radius: 10px;
		color: #fff;
	}
	.quart{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	.date{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	.dateitem{
		display: inline-block;
		 width: 80px;
		 height: 80px;
		 margin-right: 10px; 
		 border-radius: 50%;

	}
	page{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}
	.main{
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}

</style>
